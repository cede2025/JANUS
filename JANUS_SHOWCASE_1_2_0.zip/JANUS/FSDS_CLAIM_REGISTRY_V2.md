# FSDS Claim Registry v2

**Status:** epistemically frozen for v2.0 research candidate. A claim may move upward only after an explicit proof or preregistered independent validation. Negative results are retained.

## VERIFIED

These are mathematical properties of the stated model class, not empirical claims about a particular domain.

| ID | Claim | Evidence type | Conditions / scope |
|---|---|---|---|
| V1 | Linear state model can be represented as `dX_t = A X_t dt + G dW_t`. | Definition / standard SDE model class | Constant finite-dimensional A and G; Itô Wiener noise. |
| V2 | Conditional transition mean is `E[X_{t+Delta}|X_t] = exp(A Delta) X_t`. | Mathematical derivation | Linear time-homogeneous SDE; Delta >= 0. |
| V3 | Transition covariance is `Q_Delta = integral_0^Delta exp(A s) G G^T exp(A^T s) ds`. | Mathematical derivation | Same model assumptions as V2. |
| V4 | Deterministic drift is asymptotically stable iff A is Hurwitz: `max Re(lambda(A)) < 0`. | Linear-systems theorem | Finite-dimensional autonomous linear drift. |
| V5 | If A is Hurwitz, the linear Gaussian SDE admits the usual stationary Gaussian construction; covariance solves the continuous Lyapunov equation under the stated diffusion assumptions. | Mathematical result with explicit conditions | Distinguish existence of an invariant law from every stronger mixing/ergodicity statement. |
| V6 | A parameter graph can be defined with directed edge `j -> i` weighted by `A[i,j]`. | Definition | This is a graph of model parameters, not automatically a causal graph. |

## SUPPORTED

These claims have empirical or numerical support but remain contingent on design, sample size, identifiability and validation protocol.

| ID | Claim | Current status | Required strengthening |
|---|---|---|---|
| S1 | CT-NLS can recover A in low-dimensional, sufficiently informative simulations. | Supported in controlled simulations. | Power curves over T, dimension, noise, conditioning and sampling irregularity. |
| S2 | Stability can be estimated from fitted A away from the boundary. | Supported conditionally. | Confidence intervals and explicit indeterminate region near zero. |
| S3 | Graph/sign recovery is possible in favorable regimes. | Supported conditionally. | Preregistered thresholds, sparsity methods, uncertainty and larger T. |
| S4 | Continuous-time modeling can help under genuinely irregular sampling. | Supported as a model-class rationale, not universal superiority. | Fair OOS comparisons against discrete-time and state-space baselines. |
| S5 | FSDS can be used as a cross-domain methodology. | Hypothesis / framework claim. | Independent domain studies showing utility beyond shared notation. |
| S6 | Critical Transition Indicators may provide useful descriptive early-warning features in selected systems. | Supported only conditionally. | Null-model false-alarm calibration, sensitivity, change-point/Bayesian baselines. |
| S7 | Network leverage may relate to cascade severity in some systems. | Hypothesis. | Prospective train/test prediction with independent cascades and confidence intervals. |

## REJECTED / REMOVED

The following statements are not part of FSDS v2 and must not appear as positive conclusions.

| ID | Removed claim | Reason |
|---|---|---|
| R1 | **CT-VAR zawsze lepszy niż VAR**. | Counterexamples exist; at constant sampling the legacy mean-log parameterization can be prediction-equivalent to VAR. |
| R2 | **Uniwersalny CSD detector** / universal crisis detector. | False positives and false negatives exist; CSD indicators are conditional and model-dependent. |
| R3 | **Motter-Lai claim** for the legacy local cascade engine. | Legacy redistribution is not the classical global shortest-path overload model. |
| R4 | **Causal inference** from entries of A or temporal precedence alone. | A parameter graph does not identify interventional causality without additional assumptions/design. |
| R5 | **AGI/production claim** as evidence for FSDS scientific validity. | Product/AGI labels are outside the validated scientific core. |
| R6 | **Formal verification claim** based on ordinary unit/integration tests. | Testing is not formal proof. |
| R7 | `A = log(Phi)/mean(dt)` as the primary irregular-time estimator. | It discards individual sampling intervals and has branch/embeddability hazards. |
| R8 | Silently replacing complex matrix-log output with its real part. | Can destroy `exp(A Delta)=Phi`; FSDS v2 returns `NON_REAL_GENERATOR` instead. |
| R9 | Universal prediction of future cascade from leverage. | Not demonstrated out of sample. |
| R10 | Universal law / proof of world dynamics / proof of interdisciplinarity. | Not entailed by the mathematics or available experiments. |

## Promotion rule

A `SUPPORTED` claim becomes `VERIFIED` only if it is actually mathematical and receives a complete proof under explicit assumptions. Empirical claims do not become mathematical `VERIFIED`; they may instead be labelled `REPLICATED` in a future empirical evidence registry after independent preregistered replication.
