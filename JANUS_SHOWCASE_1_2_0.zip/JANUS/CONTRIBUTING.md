# Contributing / Evaluation

This repository is currently published as a controlled technical evaluation artifact.

Before changing validation logic, contracts, JANUS semantics, or release claims:

1. preserve existing negative and inconclusive findings;
2. update the relevant specification and claim registry;
3. add or update deterministic tests;
4. rerun the affected validation protocol;
5. do not upgrade a bounded result into a general claim without new evidence.

Production deployment, cloud infrastructure validation, and safety-critical certification are outside the scope of this repository.
