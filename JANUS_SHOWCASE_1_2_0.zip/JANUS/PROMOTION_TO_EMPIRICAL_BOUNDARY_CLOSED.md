# PROMOTION_TO_EMPIRICAL_BOUNDARY_CLOSED

**Current status:** `1.2.0-EMPIRICAL_BOUNDARY_CANDIDATE`  
**Target status:** `1.2.0-EMPIRICAL_BOUNDARY_CLOSED`

The software, JANUS robustness and Unified Core E2E requirements are complete. Promotion is deliberately blocked by one empirical requirement: the frozen CT-NLS-vs-VAR protocol must be executed on at least **three independently sourced public datasets** with genuinely irregular observation times. The current release contains three real irregular benchmark panels, but all derive from the Kossakowski source and therefore count as one independent source.

## Frozen independent candidates

The repository contains a deterministic fetch/materialization protocol for:

1. `0014_habets` — openESM / Habets 2020; semi-random ESM; raw timestamps; CC0 1.0.
2. `0008_westhoff` — openESM / Westhoff 2024; semi-random ESM; raw timestamps; CC BY 4.0.
3. `0062_neubauer` — openESM / Neubauer 2024; semi-random ESM; raw timestamps; CC BY 4.0.

No result is assumed in advance. Negative, inconclusive and non-convergent outcomes satisfy the empirical-execution requirement and must be retained.

## Promotion procedure

```bash
python scripts/fetch_openesm_v1_2.py
python experiments/v1_2/validate_openesm_multisubject.py
python experiments/v1_2/build_reports.py
python scripts/check_v12_empirical_gate.py
```

The last command is the only authority for promotion. It must report:

```text
EMPIRICAL_BOUNDARY_CLOSED: YES
```

Only then may `VERSION` and `STATUS` be changed to:

```text
1.2.0-EMPIRICAL_BOUNDARY_CLOSED
EMPIRICAL_BOUNDARY_CLOSED
```

## Scientific reason for the gate

Three variable panels from one cohort are useful benchmark replications but are not three independent source replications. Counting them as independent datasets would satisfy a file-count interpretation while defeating the purpose of the empirical-boundary requirement.
