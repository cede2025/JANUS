# Integration

## What exists

- `adapters/` — dict ↔ versioned contract mappers
- `tests/test_e2e_*.py` — **CONTRACT SMOKE** (schema validate + adapter roundtrip)
- `demo/` — illustrative only

## What does NOT exist yet

Full live pipeline:
ObservationEvent → PEELLL ingest → FSDS filter → BeliefState → DynamicsEstimate →
Unified Core planner → ActionProposal → Formal SafetyDecision → PEELLL audit

That path is **DEFERRED** (CLAIM C-INT-002).
