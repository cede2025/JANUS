# RELEASE GATE - JANUS / FSDS V1.1.0

Release label: `EPISTEMIC_INTEGRITY_CLOSED`
Scope: local / single-node reference runtime only.

## Mandatory gates

| Gate | Requirement | Result |
|---|---|---|
| FSDS baseline | all FSDS unit/numerical tests | PASS |
| Unified baseline | all Unified Core tests | PASS |
| PEELLL baseline | all local tests; cloud-only tests may remain explicit SKIP | PASS |
| Integration baseline | all integration tests | PASS |
| JANUS T1-T30 | 30/30 | PASS |
| Linearizability | T14 N=32 and T30 N=100 exactly one success | PASS |
| Evidence before OPEN | T15 | PASS |
| Execution TOCTOU | T13, T25-T29 | PASS |
| Restart invalidation | T29 | PASS |
| Contract schema | 1.1.0; legacy ActionProposal without dynamics/snapshot binding rejected | PASS |
| Clean manifest | SHA-256 manifest | PASS |
| Smoke | local import/persistence/JANUS bootstrap | PASS |

## Meaning of the label

`EPISTEMIC_INTEGRITY_CLOSED` means only that the tested local execution model enforces the V1.1 epistemic-integrity invariants at the linearizable permit-consume instant. It is not a claim of physical safety, formal verification, certification, cloud SLA, AGI, or exactly-once physical side effects.

A permit transition authorizes one actuator attempt after commit. A crash after CONSUMED and before an external actuator acknowledges the command remains an external side-effect problem and is outside the proof boundary of this local reference runtime.
