# A4 Extended boundary

No claim update. Function f(U)=Δε estimated on denser grid; see uncertainty_grid.csv. Performance gain remains unproven.
