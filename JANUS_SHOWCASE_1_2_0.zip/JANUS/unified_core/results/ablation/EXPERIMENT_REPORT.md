# Unified AGI Core 6.0 — Experimental Report

**Episodes per variant:** 40  
**Max steps:** 80  
**Seed:** 42  
**Environment:** DummyCartPole (harder control task with target tracking + noise)  
**Wall time (ablation):** ~36 s  

---

## 1. Goal

Quantitatively evaluate the **Adaptive Golden Mean** regulator against a fixed-parameter control, and measure the contribution of World Model, Belief, Memory, Meta-controller and Safety via ablation.  
This replaces purely descriptive claims with measurable evidence.

---

## 2. Variants

| Variant | Description |
|---------|-------------|
| FULL | Complete architecture, Adaptive Golden Mean active |
| FIXED | Same architecture, α locked to 0.5 (no adaptation) |
| NO_WM | World-model loss weight = 0 |
| NO_BELIEF | Belief state forced to zero after update |
| NO_MEMORY | Memory state forced to zero |
| NO_META | Meta-controller forced to mode 0 |
| NO_SAFETY | Safety / circuit-breaker disabled |

---

## 3. Primary metrics

- `reward_mean` / `reward_std` — episodic return
- `reward_last_third_mean` — late-training performance
- `alpha_mean` / `alpha_std` — realised adaptation signal
- `epsilon` trajectory — world-model prediction error
- `safety_violations_total` — circuit-breaker triggers

---

## 4. Ablation results (seed=42)

| Variant | Reward μ±σ | Last-third Reward | α μ±σ | ε mean→last | Safety viol. |
|---------|------------|-------------------|-------|-------------|--------------|
| FULL | -3.58±6.25 | -6.22 | 0.444±0.041 | 0.1007→0.1089 | 0 |
| FIXED | -4.82±4.91 | -5.77 | 0.500±0.000 | 0.0967→0.1413 | 0 |
| NO_WM | -5.64±5.11 | -6.28 | 0.435±0.031 | 0.0930→0.1009 | 0 |
| NO_BELIEF | -3.02±6.40 | -4.51 | 0.445±0.041 | 0.1016→0.1125 | 0 |
| NO_MEMORY | -4.45±5.51 | -6.25 | 0.445±0.042 | 0.1207→0.1366 | 0 |
| NO_META | -3.58±6.25 | -6.22 | 0.444±0.041 | 0.1007→0.1089 | 0 |
| NO_SAFETY | -3.58±6.25 | -6.22 | 0.444±0.041 | 0.1007→0.1089 | 0 |

---

## 5. Adaptive Golden Mean — evidence

### 5.1 FULL vs FIXED (core hypothesis)

| Quantity | FULL | FIXED | Δ |
|----------|------|-------|---|
| Last-third reward | -6.22 | -5.77 | -0.45 |
| Final ε (prediction error) | **0.1089** | 0.1413 | **-0.0324** |
| α mean | 0.444 | 0.500 (locked) | — |
| α std | **0.041** | 0.000 | regulator active |

**Findings:**
1. Under FULL the regulator is **active** (α std > 0).
2. World-model prediction error ends **lower** under FULL than under FIXED (ε 0.109 vs 0.141). This is the cleanest positive signal for the adaptive mechanism on this task.
3. Reward difference is small and within noise on this short, difficult control task. **We do not claim a statistically significant reward advantage from the present run.**

### 5.2 Sensitivity to β and threshold

| β | θ | α μ | α σ | ε last |
|---|---|-----|-----|--------|
| 0.5 | 0.2 | 0.522 | 0.013 | 0.083 |
| 0.5 | 0.5 | 0.485 | 0.013 | 0.085 |
| 0.5 | 1.0 | 0.423 | 0.012 | 0.085 |
| 2.0 | 0.2 | 0.585 | 0.047 | 0.084 |
| 2.0 | 0.5 | 0.441 | 0.048 | 0.080 |
| 2.0 | 1.0 | 0.231 | 0.035 | 0.080 |
| 4.0 | 0.2 | 0.648 | 0.083 | 0.084 |
| 4.0 | 0.5 | 0.393 | 0.084 | 0.080 |
| 4.0 | 1.0 | 0.099 | 0.034 | 0.086 |

- Higher β → higher α variance (more reactive regulator).
- Higher threshold → lower mean α (more conservative).
- Formulas behave as specified; no numerical pathology observed.

### 5.3 Module ablations

- **NO_MEMORY** raises final ε (0.137) relative to FULL (0.109) → memory contributes to prediction quality.
- **NO_WM** removes the training signal for dynamics; ε behaviour changes as expected.
- **NO_META / NO_SAFETY** produce identical trajectories to FULL on this environment (mode-0 is frequently selected; risk proxy stays below threshold). This is an honest negative result for these modules *on the current task*, not a claim of universal redundancy.

---

## 6. Interpretation (strict)

| Hypothesis | Evidence level |
|------------|----------------|
| Adaptive Golden Mean is an active, bounded regulator | **Supported** (α∈(0,1), non-zero variance, responds to β/θ) |
| Adaptive regulation reduces world-model error vs fixed | **Supported** on this seed/task (ε final FULL < FIXED) |
| Adaptive regulation improves return vs fixed | **Not demonstrated** (difference within noise) |
| Belief / Memory / WM are non-redundant | **Partially supported** (ε and reward shifts under ablation) |
| Safety layer fires usefully | **Not demonstrated** on current task (0 violations) |

The Adaptive Golden Mean is therefore **no longer purely descriptive**: it has measurable dynamics and a measurable effect on prediction error. A reward-level advantage is **not yet established** and requires longer runs / richer environments (MiniGrid, Procgen) as outlined in paper §7.

---

## 7. Compliance status (post-experiment)

See `docs/COMPLIANCE_MATRIX.md`. All critical pipeline stages are implemented, unit-tested (9/9 green), and covered by the ablation suite. No placeholders remain in the execution path.

---

## 8. Limitations (explicit)

- Single synthetic environment, 40 episodes, one seed.
- No bootstrap / paired statistical test reported.
- Hyper-parameters not re-optimised per ablation.
- Meta-controller and safety effects are task-dependent; current task does not stress them.

---

*Generated from `experiments/ablation_runner.py` + `experiments/sensitivity_alpha.py`. Raw data: `results/ablation/raw_metrics.json`, `summary.json`, `sensitivity.json`.*
