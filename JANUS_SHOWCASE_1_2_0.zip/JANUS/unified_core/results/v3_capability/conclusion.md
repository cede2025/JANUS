# V3 capability evidence

- GCR FULL_V3=1.000 vs V1_LIKE=0.000 better=True
- Contributions (GCR drop when removed): {'NO_MEMORY': 0.0, 'NO_SEMANTIC': 0.0, 'NO_TOOLS': 0.0, 'NO_PLANNER': 1.0, 'NO_DYNAMICS_BRIDGE': 0.0}
- Semantic KS=1.000 CR=60.00

NO_PLANNER drives GCR→0; other modules may not move synthetic GCR. Do not overclaim module necessity beyond measured contribution.
