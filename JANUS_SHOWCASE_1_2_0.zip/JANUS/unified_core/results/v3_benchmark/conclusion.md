# V3 Long Horizon + Ablation

Tool contribution (GCR FULL - NO_TOOLS) = 0.000

See benchmark.json. Integrated loop is measurable; not production AGI.


Honest note: GCR=1 on FULL/NO_* (except NO_PLANNER) reflects plan-step bookkeeping in a synthetic loop, not external task difficulty. Integration proof ≠ task intelligence proof.
