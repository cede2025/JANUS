# Trace / regression

- modules seen: ['consolidate', 'create_plan', 'decide_tool', 'dynamics_bridge', 'execute_tool', 'observe', 'retrieve_memory']
- dynamics_bridge events: 30
- p95 latency no_bridge=0.79ms with_bridge=1.16ms budget=50.00
- containment: {'NO_MEMORY': 'ok', 'NO_TOOLS': 'ok', 'NO_PLANNER': 'ok', 'BRIDGE_FAULT': 'ok'}
- regression_ok: True
