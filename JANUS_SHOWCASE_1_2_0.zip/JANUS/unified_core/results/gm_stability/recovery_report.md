# Recovery / stability report

## U=0.1
- bounded=True α∈[0.279,0.343]
- Var(Δα)=0.000019
- recovery_steps=0

## U=0.7
- bounded=True α∈[0.278,0.341]
- Var(Δα)=0.000073
- recovery_steps=0
