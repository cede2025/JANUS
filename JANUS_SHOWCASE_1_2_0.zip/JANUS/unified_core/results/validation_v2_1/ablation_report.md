# ETAP 2.1 — Scientific Expansion Report

## Primary (N=20, env=dummy)

| Quantity | Value |
|----------|-------|
| ε_FULL μ±σ | 0.1240±0.0376 |
| ε_FIXED μ±σ | 0.1230±0.0345 |
| Δε mean | -0.00102 |
| CI95(Δε) | [-0.00571, 0.00220] |
| H1 supported | **False** |
| Cohen's d | -0.028 |
| Reward FULL / FIXED | 3.754 / 4.045 |

**Strict note:** At N=5, H1 was accepted; at N=20 the primary CI includes 0. The small-N result does not generalize at this scale on dummy.

## Multi-environment

| Env | Δε mean | CI95 | H1 |
|-----|---------|------|-----|
| dummy | -0.00216 | [-0.01178, 0.00374] | False |
| noisy | 0.00284 | [0.00072, 0.00524] | True |
| grid | -0.00589 | [-0.01945, 0.00410] | False |

## Adaptive ablations (ε_variant − ε_FULL; >0 ⇒ FULL better)

| Variant | Δε mean | CI95 | worse than FULL (CI) |
|---------|---------|------|----------------------|
| FIXED | -0.00216 | [-0.01159, 0.00391] | False |
| NO_ADAPTIVE | -0.00216 | [-0.01166, 0.00370] | False |
| RANDOM_ALPHA | 0.00364 | [-0.03317, 0.03978] | False |
| FIXED_OPTIMAL | -0.00216 | [-0.01164, 0.00388] | False |