# Ablation report (FULL vs FIXED) — ETAP 2

## Setup
- Seeds: [0, 1, 2, 3, 4]
- Episodes/seed: 15
- Max steps: 40
- Bootstrap samples: 2000

## Results
| | FULL | FIXED |
|--|------|-------|
| ε last-third μ±σ | 0.1230±0.0262 | 0.1326±0.0318 |
| Reward last-third μ | 7.938 | 8.129 |

## Δε = ε_FIXED − ε_FULL
- mean: 0.00954
- 95% CI: [0.00427, 0.01504]
- Cohen's d: 0.327

## H1: E(ε_FULL) < E(ε_FIXED)
**SUPPORTED (CI lower bound > 0)**
