# Dynamics consolidation

- H1 (∃k short, bridge < linear): **True**
- H2 (identity sometimes best): **True**
- H3 AlarmGain=0.593 useful=True

Bridge remains **experimental passive utility**, not general dynamics architecture.
GM claims unchanged.
