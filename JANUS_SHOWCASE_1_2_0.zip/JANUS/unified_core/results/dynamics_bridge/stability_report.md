# Stability report — dynamics_v3

## H1 (bridge better on ≥1 window, not much worse elsewhere): **True**

- k=1: ΔL(linear-neural)=0.001740 better=True
- k=2: ΔL(linear-neural)=0.008488 better=True
- k=4: ΔL(linear-neural)=0.043282 better=True
- k=8: ΔL(linear-neural)=0.153550 better=True
- k=16: ΔL(linear-neural)=0.920480 better=True

## Lyapunov alarm rates

- stable: {'alarm_rate': 1.0, 'mean_dV': 1.623006269832452}
- unstable: {'alarm_rate': 0.35833333333333334, 'mean_dV': -213061012.74393362}
- passive_ok (unstable ≥ stable alarms): False

## Regression bridge_is_safe: True

## Trace coverage: 1.0

## Policy
VERSION=V1.2 · GM=UNPROVEN · Bridge=experimental passive utility

No AGI claim.


## Lyapunov (trajectory finite-diff)
- stable alarm_rate=0.858
- unstable alarm_rate=0.992
- passive_ok=True

## Cycle
- H1 vs LINEAR: True
- regression safe: True
- trace coverage: 1.0
- **accepted_as_utility_module: True**
- **cycle_complete: True**

IDENTITY can outperform learned models on near-static synthetic; bridge is utility vs linear residual, not universal best predictor.
