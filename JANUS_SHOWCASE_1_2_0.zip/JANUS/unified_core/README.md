# Unified Core V1.2 — Agent Orchestration

**Status:** RESEARCH_CANDIDATE  
**Role (SPEC-011):** goals, planning, task decomposition, tool selection, episodic memory, agent orchestration, deliberation, action proposal.

> Research prototype — **not a claim of AGI** (SPEC-005, SPEC-055).

Package directory is still named `agi_core` for historical lineage; this is naming debt, not a capability claim.

## Safety

`agi_core.safety.safety_layer.SafetyLayer` is a **heuristic** projection + risk proxy on action logits.  
It is **not** the formal dynamical SafetyFilter required by SPEC-077 (CBF/CLF + DynamicsEstimate).  
Formal dynamical safety assessment belongs to FSDS; authorization safety to PEELLL; this layer is runtime policy helper only.

## Tests

```bash
python3 -m pytest tests/ -q
```

71 tests currently cover planner, memory separation, dynamics bridge, failure modes, etc.
