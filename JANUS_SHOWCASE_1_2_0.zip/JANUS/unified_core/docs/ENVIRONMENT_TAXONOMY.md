# Environment Taxonomy (ETAP 2.2)

| Class | Name | Members | Hypothesis for Adaptive GM |
|-------|------|---------|----------------------------|
| **A** | Stable / low noise | `dummy` (deterministic-ish control) | May show **no** advantage |
| **B** | Variable / stochastic | `noisy` | **May help** (V2.1: H1 supported) |
| **C** | Dynamic / non-stationary | `switching` (mid-episode parameter change) | **Highest expected value** of regulation |

Results must be reported **per class**, never pooled as a single universal Δε.
