# Macierz zgodności — Unified AGI Core 6.0 vs Paper + załączniki

| ID | Wymaganie / Komponent (źródło) | Implementacja | Test / Dowód | Status |
|----|--------------------------------|---------------|--------------|--------|
| P-3.2 | Formalne przestrzenie S,O,X,Z,M,B,P,G,A | `Config` dimensions | `test_core.py` dim checks | DONE |
| P-3.3-1 | Observacja → Percepcja | `Perception` | unit test | DONE |
| P-3.3-2 | Encoding latent | `WorldModel.encode` | unit test | DONE |
| P-3.3-3 | Prediction dynamics | `WorldModel.predict` | unit test + ε metric | DONE |
| P-3.3-4 | Belief update | `BeliefEngine` | unit test + NO_BELIEF ablation | DONE |
| P-3.3-5 | Memory update | `MemoryEngine` (GRU + importance) | unit test + NO_MEMORY ablation | DONE |
| P-3.3-6 | Planner | `Planner` | unit test | DONE |
| P-3.3-7 | Meta-controller | `MetaController` | unit test + NO_META ablation | DONE |
| P-3.3-8 | Action proposal | `ActionHead` | unit test | DONE |
| P-3.3-9 | Safety filter Ω | `SafetyLayer` (project + circuit breaker) | unit test + NO_SAFETY | DONE |
| P-3.4 | Multi-term loss J | `Trainer.update` | loss terms logged | DONE |
| P-3.5 | Adaptive regulation (α,τ,λ_safe,H,reg) | `AdaptiveLoop` | FULL vs FIXED experiment | DONE |
| P-4.1 | Latent stability (Lipschitz-friendly) | MLP dynamics + LayerNorm | ε trajectory | PARTIAL |
| P-4.2 | Safety invariance | projection + hard stop | violation counts | DONE |
| P-4.3 | Memory boundedness | importance gate ∈ (0,1) | code + unit | DONE |
| P-4.4 | Belief consistency (bounded) | tanh output | code | DONE |
| P-4.5 | Regulator boundedness α∈(0,1) | sigmoid | α statistics | DONE |
| P-5 | ASCII architecture diagrams | README + ARCHITECTURE.md | docs | DONE |
| P-6 | Reference layout | package structure | tree | DONE |
| P-7 | Experimental plan + ablations | `ablation_runner.py` | report | DONE |
| A-5.2 | Adaptive Golden Mean formulas | exact port from Agis7.0 | unit + experiment | DONE |
| CSAR | Hard-stop / circuit-breaker philosophy | `SafetyLayer` risk gate | NO_SAFETY contrast | DONE |
| AUDIT | WORM audit trail | `WormLogger` | log files present | DONE |

**Legenda statusu**  
- DONE = zaimplementowane + pokryte testem lub eksperymentem  
- PARTIAL = zaimplementowane, pełny formalny dowód otwarty  

Brak placeholderów w ścieżce krytycznej (agent step, trainer, adaptive, safety).

---

## Mathematical correctness layer (added)

| ID | Statement | Formal status | Machine check |
|----|-----------|---------------|---------------|
| M-3.1 | α∈(0,1), induced hyperparams bounded | Proposition 3.1 | `test_prop_31_*` |
| M-4.1 | Safety projection never selects masked actions | Theorem 4.1 | `test_thm_41_*` |
| M-5.1 | Memory = convex combination, gate∈(0,1) | Proposition 5.1 | `test_prop_51_*` |
| M-6.1 | Belief coordinates ∈(-1,1) | Proposition 6.1 | `test_prop_61_*` |
| M-7.1 | Local contraction of F_φ | Design criterion / conjecture | empirical ε only |
| M-8.1 | Closed-loop signals finite on finite horizon | Theorem 8.1 | `test_thm_81_*` |

Full proofs and separation of theorem / empirical claims:  
`docs/MATHEMATICAL_CORRECTNESS.md`
