# Unified AGI Core — Roadmap Status V1 → V5

Mapping of the current package against the production roadmap
(`Pasted Text` specification: V1 core → V5 production).

---

## Summary

| Version | Status | Evidence |
|---------|--------|----------|
| **V1** Working closed loop | **ACHIEVED** | 15+ unit tests, 1000-step run, WORM log, math invariants, acceptance tests |
| **V2** Cognitive validation & learning stability | **PARTIAL → advanced** | Ablation runner, sensitivity sweep, multi-term loss, FULL vs FIXED; multi-seed CI still open |
| **V3** Long-term memory, tools, multi-horizon | **NOT STARTED** | Architecture reserved; modules not present |
| **V4** Scale, distribution, governance | **NOT STARTED** | — |
| **V5** Production reliability & compliance | **NOT STARTED** | — |

Invariant chain (roadmap §7):

\[
C(V1) \subset C(V2) \subset \cdots \subset C(V5)
\]

Current work preserves all V1 guarantees while extending measurable V2 evidence.

---

## V1 — Acceptance matrix (roadmap §1.5)

| Criterion | Status | Evidence |
|-----------|--------|----------|
| Full cycle perception→…→safety→action without manual intervention | ✓ | `UnifiedAGIAgent.step` |
| 1000+ steps uninterrupted | ✓ | `test_v1_1000_steps_no_nan` |
| No None / NaN on path | ✓ | same + invariant tests |
| WORM log every step | ✓ | `test_v1_worm_log_every_step` |
| Unit contract tests pass | ✓ | 15 tests green |
| ≥1 closed-loop benchmark E2E | ✓ | DummyCartPole / trainer |
| Totality (Thm 1) | ✓ | composition of total maps + tests |
| Boundedness of regulator (Thm 2 / Prop 3.1) | ✓ | math doc + `test_prop_31_*` |
| Safety non-expansion (Thm 3 / Thm 4.1) | ✓ | math doc + `test_thm_41_*` |
| Determinism under seed | ✓ | `test_v1_determinism_under_seed` |

**V1 is frozen as the stable core.** Further changes to the step pipeline require a version bump and regression of the V1 suite.

---

## V2 — Status vs roadmap §2

| Capability | Status | Notes |
|------------|--------|-------|
| World-model training signal | ✓ | `J_wm` in Trainer |
| Policy / value training | ✓ | PG + value loss |
| Ablation runner | ✓ | FULL / FIXED / NO_* |
| Sensitivity sweep for α | ✓ | β × threshold |
| Rolling-origin / blocked CV | ✗ | not yet |
| Multi-seed evaluation + CI | ✗ | single seed reported; harness exists |
| Thm 4 (local descent) | design | small lr + grad clip; not formally verified on landscape |
| Thm 5 (ablation logic) | empirical | deltas measured; confidence intervals open |

**V2 next concrete steps (Stage B):**
1. Multi-seed wrapper (`seeds = [0,1,2,3,4]`) around `ablation_runner`
2. Bootstrap CI on reward / ε deltas
3. Optional blocked cross-validation on longer trajectories

---

## V3–V5 — Explicitly out of current scope

Interfaces reserved in `docs/ARCHITECTURE.md` and AgentContract (roadmap §6.1).  
No code paths claim V3+ capabilities. This avoids the descriptive fallacy.

---

## Formal bridge to mathematical correctness

Roadmap theorems map as follows:

| Roadmap | Math document | Code check |
|---------|---------------|------------|
| Thm 1 Totality | Thm 8.1 well-posedness | `test_thm_81_*`, `test_v1_1000_*` |
| Thm 2 Boundedness α | Prop 3.1 | `test_prop_31_*` |
| Thm 3 Safety non-expansion | Thm 4.1 | `test_thm_41_*` |
| Thm 4 Local descent | design criterion | grad clip + small lr |
| Thm 5 Ablation logic | experimental identification | `EXPERIMENT_REPORT.md` |

---

## Version tag

Package version remains **6.0.0** (paper lineage).  
Roadmap maturity tag: **V1 complete / V2 partial**.

```
unified_agi_core_6.0  ==  Roadmap V1 ✓ + V2 evidence layer
```

---

## V2 multi-seed update (3 seeds × 15 episodes)

| Metric | FULL | FIXED | Cohen's d |
|--------|------|-------|-----------|
| Reward last-third μ | 8.07 ± 3.89 | 8.11 ± 3.99 | **−0.01 (negligible)** |
| ε last-third μ | **0.133 ± 0.030** | 0.147 ± 0.034 | **+0.45 (small, FULL better)** |
| α μ | 0.436 (active) | 0.500 (locked) | — |

Consistent with single-seed report: Adaptive Golden Mean reduces prediction error; return advantage not established.
