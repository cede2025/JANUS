# Meta-analiza — dźwignie i decyzja wersji

## 1. Stan faktyczny (nie aspiracyjny)

| Warstwa | Fakt |
|---------|------|
| Zamknięta pętla agentowa | Działa, 1000+ kroków, 19 testów |
| Dowód matematyczny struktury | Prop 3.1, Thm 4.1, 5.1, 6.1, 8.1 |
| Adaptive Golden Mean | Aktywny, ogranicza ε (d≈0.45), **nie** poprawia returnu istotnie |
| Ablacje / multi-seed | Są |
| Long-term memory / tools (V3) | **Brak** |
| Orchestrator / queue / checkpoint (V4) | **Brak** |
| Authz / SLO / multi-tenant (V5) | **Brak** |

Paper lineage nazywał projekt „6.0”. Roadmapa definiuje V1–V5.  
**Nazwa wersji nie może pochodzić z numeru paperu ani z życzenia „produkcja V4”.**

## 2. Decyzja wersji (z dokumentu matematycznego)

Dokument `MATHEMATICAL_CORRECTNESS.md` ustala:

- **Twierdzenia strukturalne** dotyczą pętli V1 (totality, boundedness α, safety, well-posedness).
- **Empiria V2** (ε, ablacje) jest mierzona, ale nie podnosi systemu do V3+.
- Żaden dowód nie dotyczy orchestracji, izolacji workerów, authz ani SLO.

**Kanoniczna wersja pakietu: `V1.2`**

- `V1` — zamknięta pętla + niezmienniki udowodnione  
- `.2` — warstwa empirii V2 (ablacje, sensitivity, multi-seed) bez roszczenia pełnego V2 (brak CI/bootstrap na pełnej skali)

**Nie jest to V4 ani V5 production.** Nazywanie tego V4 byłoby sprzeczne z roadmapą §4–§5 i z dowodem matematycznym.

## 3. Dźwignie (maksymalny efekt / jednostka czasu)

| # | Dźwignia | Dlaczego | Priorytet |
|---|----------|----------|-----------|
| L1 | **Uczciwa wersja + ledger braków** | Usuwa dług zaufania; każda paczka czytelna | ZROBIONE w tym wydaniu |
| L2 | **Zamrożenie kontraktu `step()`** | V1 regression suite = kotwica | ZROBIONE |
| L3 | **Multi-seed + effect size na ε** | Jedyne twarde wsparcie Adaptive GM poza narracją | ZROBIONE (3 seedy) |
| L4 | Bootstrap CI / 5 seedów | Domknięcie V2 statystycznie | Następne |
| L5 | Long-term memory + retrieval metrics | Wejście w V3 — największy skok zdolności | Po L4 |
| L6 | Orchestrator + checkpoint | V4 — dopiero gdy V1–V3 stabilne | Później |
| L7 | Authz / SLO / chaos | V5 — ostatnie | Później |

**Anty-dźwignie (unikać):**
- Rozbudowa numeru wersji bez nowych twierdzeń / testów
- Stuby V4/V5 prezentowane jako „production”
- Optymalizacja returnu na DummyCartPole zamiast bogatszego env

## 4. Co ta paczka dostarcza jako „production-oriented artifact”

Nie runtime V4, lecz **artefakt badawczy o jakości produkcyjnej**:

- deterministyczne testy, acceptance gate, WORM audit
- matematyczna poprawność oddzielona od empirii
- `NOT_IMPLEMENTED.md` obowiązkowy przy każdym ZIP
- manifest wersji powiązany z dowodem, nie z marketingiem

## 5. Reguła na kolejne paczki

Przy każdym ZIP:

1. Wersja = f(dowód matematyczny + C(V_k) z roadmapy)  
2. Plik `NOT_IMPLEMENTED.md` aktualny  
3. Żadne stuby bez prefiksu `STUB` / statusu w ledgerze  
4. Testy ≥ poprzedniej liczby zielonych
