# PROJECT CONTROL — Unified AGI Core

**VERSION:** V1.2  
**VALIDATION LAYER:** V2 FINAL CLOSED  
**CLASSIFICATION:** Research Validated Core  

## Adaptive GM status

| | |
|--|--|
| Role | adaptive control mechanism |
| Activity / boundedness | **high confidence** |
| Universal (or stable noisy) performance gain | **not demonstrated** (replication failed) |

## Tracks

- **Track A (science):** boundary conditions for adaptation — not more binary success tests.  
- **Track B (V3):** capability expansion (memory/tools/planning) under a **separate** hypothesis from GM performance.

## Rules

1. Do not delete Adaptive GM.  
2. Do not promote it as proven advantage.  
3. Do not bump version to “V2 product”.  
4. V3 does not require GM victory.  

See `docs/RESEARCH_STATUS.md` and `results/validation_v2_final/conclusion.md`.
