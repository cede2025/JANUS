# Research Status — Unified AGI Core V1.2

**VERSION:** V1.2 (unchanged)  
**Validation layer:** V2 CLOSED  
**Classification:** Research Validated Core  

## Adaptive Golden Mean — dual confidence

| Aspect | Status | Confidence |
|--------|--------|------------|
| Implemented in closed loop | Yes | High |
| Bounded (α∈[0,1], induced hyperparams) | Proven (math + tests) | High |
| Active (Var(Δα)>0, responds to error) | Demonstrated | High |
| Universal performance gain vs FIXED | **Not demonstrated** | — |
| Reliable gain in noisy envs after replication | **Not confirmed** | Low |

### Role (architectural)

```
Adaptive GM
  Role:        adaptive control mechanism
  Confidence:  high for activity / boundedness
  Confidence:  low for universal (or class-B) performance gain
```

**Do not:** remove the module · market as proven advantage · treat V2 as product version bump.  
**Do:** keep as optional regulation layer; evaluate under explicit boundary-condition studies (Track A).

## Evidence summary

- **Discovery:** positive Δε signal in noisy settings (CI above 0 on early seeds).  
- **Pre-registered replication (seeds 100–119):** failed success criterion  
  Δε = −0.00074, CI₉₅ = [−0.0020, +0.0004], \(0 \in CI\).  
- **H₀** (no improvement) not rejected under the locked protocol.

## Separation of concerns

1. **Regulator dynamics** — confirmed active and bounded.  
2. **Functional value on ε** — unresolved / mixed; not a shipping claim.

## Dual track (next)

| Track | Goal | Not the goal |
|-------|------|----------------|
| **A — Scientific** | Boundary conditions: when adaptation helps, hurts, or is neutral; noise→adaptation→performance | Another binary “does it work?” |
| **B — Agent capability (V3)** | Memory / tools / subgoals for tasks V1 cannot express | Reward for GM “winning” |

V3 hypothesis (Track B) is independent:

\[
goal \rightarrow subgoals \rightarrow memory \rightarrow tools \rightarrow action
\]

not contingent on Adaptive GM superiority.

## Forbidden claims

- Universal improvement · confirmed noisy-only upgrade · AGI · V4/V5 production  
- “V2 product” version number  

## Allowed claims

- Closed-loop V1.2 core with verified contracts, safety, recovery  
- Adaptive GM as active, bounded control mechanism with **unproven** performance superiority  
