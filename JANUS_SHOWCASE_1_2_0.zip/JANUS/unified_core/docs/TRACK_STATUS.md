# Track Status — post dynamics consolidation

**VERSION:** V1.2  
**GM:** UNPROVEN  
**Bridge:** experimental passive utility  
**Label:** V3 Integrated Cognitive Agent Prototype  

## H — Dynamics consolidation
| Gate | Result |
|------|--------|
| H1 ∃ short k, bridge < linear | True |
| H2 identity sometimes best | True |
| H3 AlarmGain > 0 | True (~0.59) |

## I — Fused loop hardening
| Gate | Result |
|------|--------|
| regression / budget | True (p95≪budget) |
| failure containment | True (NO_MEMORY/TOOLS/PLANNER/BRIDGE_FAULT) |
| dynamics trace events | >0 when bridge on |

## J — Capability evidence (synthetic)
| Gate | Result |
|------|--------|
| GCR V3 > V1_LIKE | True (1.0 vs 0.0 mechanical) |
| Module contribution | **NO_PLANNER** dominates GCR; memory/tools/bridge ≈0 on synthetic GCR |
| Semantic KS / CR | KS=1.0, CR=60 |

**Honest limit:** synthetic GCR measures plan bookkeeping, not hard-task skill.
