# Pre-registration — V2 Final (Adaptive GM)

**Protocol:** frozen validation protocol (config withheld from this evaluation package)  
**Version:** V1.2  
**Date locked:** before replication run  
**Rule:** outcomes below are evaluated against this text; post-hoc metric changes are invalid.

## Hypothesis
Adaptive GM improves world-model prediction error **in uncertain (class B / high-noise) environments** relative to FIXED α.

\[
H_1:\ E[\varepsilon_{\mathrm{FULL}} \mid \text{uncertain}] < E[\varepsilon_{\mathrm{FIXED}} \mid \text{uncertain}]
\]

Equivalently: bootstrap CI₉₅ of \(\Delta\varepsilon=\varepsilon_{\mathrm{FIXED}}-\varepsilon_{\mathrm{FULL}}\) has lower bound \(> 0\).

## Primary metric
- `epsilon_world_model` (last-third episode mean of latent prediction MSE)

## Secondary metrics
- return (last-third)
- alpha stability (mean / std of α)
- recovery_time (steps after perturbation; from mechanism suite)

## Success
CI95 lower bound of \(\Delta\varepsilon > 0\) on **noisy / high-uncertainty** condition in replication seeds.

## Failure
CI95 contains 0 on the pre-registered uncertain condition.

## Not tested as primary
Universal advantage · intelligence · V3 capabilities

## Seed policy (replication)
New seeds: `{100,101,...,119}` (N=20), same episodes/steps as frozen protocol.
