# NOT IMPLEMENTED — obowiązkowy ledger braków

**Wersja pakietu:** V1.2  
**Podstawa wersji:** `docs/MATHEMATICAL_CORRECTNESS.md` (Thm 1/3/4.1/8.1 + Prop 3.1/5.1/6.1)  
**Data ledgeru:** przy każdym wydaniu ZIP ten plik musi być obecny.

---

## Zaimplementowane (V1 + warstwa empirii V2)

| Element | Status |
|---------|--------|
| Perception → World Model → Belief → Memory → Planner → Meta → Policy → Safety | ✓ |
| Adaptive Golden Mean (α, τ, λ_safe, H, reg) | ✓ |
| WORM audit logger | ✓ |
| Trainer (multi-term loss) | ✓ |
| Ablation runner | ✓ |
| Sensitivity β/θ | ✓ |
| Multi-seed FULL vs FIXED | ✓ (3 seedy) |
| V1 acceptance gate (1000 steps, determinism, WORM) | ✓ |
| Mathematical invariants tests | ✓ |

---

## Z roadmapy V2 — brak pełnego domknięcia

| Element (roadmap §2) | Status | Uwaga |
|----------------------|--------|-------|
| Rolling-origin / blocked cross-validation | **NIE** | |
| Pełne multi-seed CI (≥5 seedów) + bootstrap CI | **NIE** | są 3 seedy, bez bootstrap |
| Formalny dowód lokalnego spadku loss (Thm 4) | **NIE** | tylko grad clip + mały lr |

---

## V3 — całkowicie niezaimplementowane

| Element (roadmap §3) | Status |
|----------------------|--------|
| Long-term memory store (vector + metadata) | **NIE** |
| Retrieval with scoring | **NIE** |
| Tool router | **NIE** |
| Subgoal graph / multi-horizon planner | **NIE** |
| Episodic summarizer | **NIE** |
| Temporal credit assignment (zaawansowane) | **NIE** |

Memory w kodzie = GRU roboczo-epizodyczna krótka, **nie** long-term store z V3.

---

## V4 — całkowicie niezaimplementowane

| Element (roadmap §4) | Status |
|----------------------|--------|
| Agent orchestrator | **NIE** |
| Worker pool / queueing | **NIE** |
| Checkpointing / restore | **NIE** |
| Distributed memory | **NIE** |
| Policy governance | **NIE** |
| Traceability matrix (platformowa) | **NIE** |
| Telemetry / SLO runtime | **NIE** |
| Fault isolation między workerami | **NIE** |

---

## V5 — całkowicie niezaimplementowane

| Element (roadmap §5) | Status |
|----------------------|--------|
| Authz (RBAC/ABAC) | **NIE** |
| Secret management | **NIE** |
| Multi-tenant isolation | **NIE** |
| Rate limits / idempotency keys | **NIE** |
| Chaos / failure injection | **NIE** |
| Blue-green / rollback deploy | **NIE** |
| Model governance produkcyjne | **NIE** |
| Data retention / deletion policies | **NIE** |
| Incident response playbooks | **NIE** |

---

## Świadomie nieclaimowane

- **To nie jest V4 production.**  
- **To nie jest V5 production.**  
- **To nie jest AGI.**  
- Numer „6.0” z paperu został **porzucony** na rzecz wersji roadmapowej opartej o dowód matematyczny: **V1.2**.

Safety layer = projekcja + prosty circuit breaker na proxy ryzyka belief; **nie** pełny stack compliance V5.

---

## ETAP 1 Hardening (added under freeze — no new capabilities)

| Item | Status |
|------|--------|
| AgentContract (reset / step_contract / validate_state) | ✓ |
| tests/determinism | ✓ |
| tests/numerical (incl. Var(α)>0) | ✓ |
| tests/regression | ✓ |
| tests/serialization | ✓ |
| tests/failure_modes | ✓ |
| New cognitive modules | **NIE** (zakaz Stage 0) |
| Version bump beyond V1.2 | **NIE** |

---

## ETAP 1.1 / ETAP 2 progress

| Item | Status |
|------|--------|
| Recovery invariance | ✓ |
| Safety dominance | ✓ |
| Corrupt containment | ✓ |
| Long-run stability gate | ✓ (default T=20k; env LONG_RUN_T) |
| Multi-seed N≥5 + bootstrap CI on Δε | ✓ (N=5, H1 supported on ε) |
| N=10 seeds | optional stretch |
| V3/V4/V5 modules | **NIE** |

---

## ETAP 2.1

| Item | Status |
|------|--------|
| N=20 primary FULL vs FIXED | ✓ (H1 NOT accepted on dummy) |
| Multi-env dummy/noisy/grid | ✓ (H1 only on noisy) |
| Bootstrap CI B=5000 | ✓ |
| RANDOM_ALPHA / FIXED_OPTIMAL ablations | ✓ |
| V3+ modules | **NIE** |

---

## ETAP 2.2
| Item | Status |
|------|--------|
| Frozen protocol YAML | ✓ |
| Taxonomy A/B/C | ✓ |
| Exists-E hypothesis | ✓ (B only) |
| Regression Noise/Dynamics | ✓ |
| Sensitivity surface | ✓ |
| Mechanism stability | ✓ |
| V3 modules | **NIE** |

---

## V2 Final (2.3)
| Item | Status |
|------|--------|
| Pre-registration | ✓ |
| Replication N=20 new seeds | ✓ (success=False) |
| Mediation analysis | ✓ descriptive |
| Robustness full CI grid | partial (budget) |
| V3 modules | **NIE** |

---

## Cycle Track A/B (post-V2)
| Item | Status |
|------|--------|
| A1 U-grid map | ✓ (weak + only at U=1) |
| A2 causality | ✓ (FULL≈FIXED → not causal for ε) |
| A3 stability | ✓ bounded |
| B1 episodic memory | ✓ store+retrieval+Recall@K test |
| B2–B5 | **NIE** |
| Claim changes to V2 | **NIE** (frozen) |

---

## V3.1 Tools
| Item | Status |
|------|--------|
| B3 registry/executor/validator/permissions | ✓ |
| B4 decision layer | ✓ |
| Built-in tools (4) | ✓ |
| B2 semantic / B5 planning | **NIE** |
| External API tools | **NIE** |
| GM claim change | **NIE** |

---

## V3.2 / V3.3
| Item | Status |
|------|--------|
| B2 semantic + consolidation | ✓ |
| A5 adaptive monitor | ✓ |
| B5 goal graph planner (minimal) | ✓ |
| B5.1 long-horizon suite | partial |
| Fused obs→memory→plan→tool loop | **NIE** (components only) |
| V3 Production / version bump | **NIE** |

---

## V3.4 / V3.5
| Item | Status |
|------|--------|
| Fused cognitive loop | ✓ |
| Execution traces | ✓ |
| Long-horizon synthetic benchmark | ✓ (mechanical GCR) |
| Ablations | ✓ |
| Hard-task long-horizon superiority | **NIE** |
| V3 Production | **NIE** |

---

## Dynamics bridge (JANUS step 1/4 lite)
| Item | Status |
|------|--------|
| Residual Neural ODE step + fit | ✓ experimental |
| Lyapunov passive monitor | ✓ |
| Free energy / mirror agents / full adjoint | **NIE** |
| AGI claim | **NIE** |

---

## Dynamics validation cycle
| Item | Status |
|------|--------|
| D1 window benchmark | ✓ H1 vs LINEAR |
| D2 Lyapunov passive alarms | ✓ unstable > stable |
| D3 baselines | ✓ IDENTITY/LINEAR/NEURAL |
| E1/E2 passive V3 + trace | ✓ |
| F2 regression gate | ✓ bridge_is_safe |
| AGI / GM claim change | **NIE** |
