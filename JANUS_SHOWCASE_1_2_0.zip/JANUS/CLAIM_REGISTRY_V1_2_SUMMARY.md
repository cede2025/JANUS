# CLAIM_REGISTRY_V1_2 — showcase summary (redacted)

The full claim registry (`CLAIM_REGISTRY_V1_2.md`) states every claim together with its exact operating parameters and per-scenario numeric results. That level of detail is withheld from this showcase because it doubles as the JANUS operating specification. This page gives the same honest PASS/FAIL/FALSIFIED accounting without the numbers needed to reproduce it.

## JANUS robustness (5-scenario Monte Carlo harness)

| Scenario | What it stresses | Outcome at the preregistered operating point |
|---|---|---|
| S1 — gradual stable drift | mechanism-shift detection without a stability short-circuit | **FALSIFIED** — preregistered sensitivity target not met; retained as an honest negative result |
| S2 — sudden regime shift | fast detection of abrupt change | **SUPPORTED** |
| S3 — sensor degradation/dropout | recovery via re-acquisition rather than false action | **SUPPORTED** |
| S4 — out-of-distribution shift | detection under distribution change | **FALSIFIED** — preregistered sensitivity target not met; retained as an honest negative result |
| S5 — execution-time constraint mutation | permit revocation after authorization changes mid-flight | **SUPPORTED** |

Negative results (S1, S4) are reported as such rather than reframed — this is a deliberate project policy (see `unified_core`'s "no claim inflation" stance) and one of the things worth noting about how this team handles evidence, not something to read as a weakness to hide.

## Unified Core end-to-end

Regime-shift scenario: the system correctly detects the mechanism change and re-identifies its model, then resumes toward the goal — tested in simulation, not claimed as a physical-plant result.

## What's withheld here specifically

- The exact preregistered threshold value(s) used as the JANUS operating point.
- Per-scenario TPR/FPR-like numbers and confidence intervals.
- The Monte Carlo trial design (scenario/epsilon/replicate structure) in enough detail to rebuild the harness.

Full quantitative results, `RELEASE_GATE_V1_2.md`, and `RELEASE_NOTES_V1_2.md` are available for qualified technical evaluation under separate written agreement.
