# CLAIM_REGISTRY.md — JANUS ECOSYSTEM V1

Status vocabulary: PROVEN | SUPPORTED | PARTIAL | DEFERRED | BLOCKED | FALSIFIED | REJECTED | UNVERIFIED | TESTED

| claim_id | component | claim | status | evidence | scope / notes |
|----------|-----------|-------|--------|----------|---------------|
| C-FSDS-001 | FSDS | expm transition F=exp(A Δt) | TESTED | test_linear_sde_transition.py, test_matrix_functions.py | linear SDE |
| C-FSDS-002 | FSDS | process covariance Q_Δ (Van Loan) | TESTED | test_process_covariance.py | continuous-discrete |
| C-FSDS-003 | FSDS | irregular individual Δt (no mean-dt primary) | TESTED | test_irregular_dt.py | SPEC-030/035 |
| C-FSDS-004 | FSDS | missing obs ≠ zero | TESTED | test_missing_observation.py | SPEC-039 |
| C-FSDS-005 | FSDS | CT-NLS residual sensitivity / gradient check | TESTED | test_ctnls_gradient.py, test_ct_nls.py | finite-diff |
| C-FSDS-006 | FSDS | spectral abscissa / Hurwitz via assess_stability | TESTED | test_stability_graph.py | nominal model |
| C-FSDS-007 | FSDS | near-Jordan expm finite | TESTED | test_near_jordan.py | numerical hardening |
| C-FSDS-008 | FSDS | filter update reduces variance; all-missing keeps prior | TESTED | test_filter_update.py | CD-KF style |
| C-FSDS-009 | FSDS | prediction interval contains mean | TESTED | test_prediction_interval.py | basic |
| C-FSDS-010 | FSDS | DynamicsGraph = predictive edges (not causal) | SUPPORTED | graph.py + docs | formal naming |
| C-UC-001 | Unified Core | Planner returns ActionProposal | TESTED | tests/planning_v3/test_planner.py | deterministic |
| C-UC-002 | Unified Core | 71 unit tests pass | TESTED | unified_core/tests/ | suite |
| C-UC-003 | Unified Core | SafetyLayer is heuristic only (not formal CBF/CLF) | SUPPORTED | safety_layer.py + README | SPEC-077 gap documented |
| C-UC-004 | Unified Core | RuntimeSafetyGate is fail-closed for OOD/low-stability contract states | TESTED | integration/tests/test_live_local_pipeline.py | not a CBF/CLF proof |
| C-PEELLL-004 | PEELLL | Audit is awaited and fail-closed in the local persistence path | TESTED | peelll/tests/integration/test_local_persistence.py | SQLite reference runtime |
| C-PEELLL-001 | PEELLL | Operational platform role (API/audit/registry) | TESTED | peelll/tests/ + integration/tests/test_live_local_pipeline.py | local reference runtime |
| C-PEELLL-002 | PEELLL | JWT/RBAC present and API path tested | TESTED | peelll/tests/unit/test_rbac.py; peelll/tests/integration/test_api.py | local reference runtime |
| C-PEELLL-003 | PEELLL | No 99.9% SLA / 2000 req/s claim | PROVEN | peelll/README.md sanitized | SPEC-005 |
| C-INT-001 | Integration | Contract E2E schema roundtrip | TESTED | integration/tests/test_e2e_*.py | contract-level only |
| C-INT-002 | Integration | Live local pipeline FSDS → Unified proposal → safety → PEELLL persistence/audit | TESTED | integration/tests/test_live_local_pipeline.py; integration/runtime_pipeline.py | local reference runtime |

## REJECTED / DEPRECATED (must not reappear as affirmative claims)

| claim_id | claim | reason |
|----------|-------|--------|
| C-LEG-001 | Motter-Lai cascade universal | no replication; synthetic reference only |
| C-LEG-002 | Formal verification of whole system | out of V1 scope |
| C-LEG-003 | AGI / universal intelligence | out of scope (SPEC-005/055) |
| C-LEG-004 | 2000 req/s guaranteed | no measurement |
| C-LEG-005 | 99.9% SLA | no soak test |
| C-LEG-006 | Causal inference platform (PEELLL) | PEELLL is operational, not causal theory |
| C-LEG-007 | formally verified / mathematically proven (PEELLL) | no proof artifacts |

| C-DATA-001 | Validation | Real AWS VM telemetry executed on three hashed samples | TESTED | evidence/real_data/real_validation.json | predictive/descriptive only |
| C-DATA-002 | Validation | EMA N=50 preregistered comparison is inconclusive | TESTED | evidence/real_data/ema_lopo_50_aws.json | CI crosses zero |

## JANUS V1.1 canonical execution-integrity claims

| claim_id | component | claim | status | evidence | scope / notes |
|----------|-----------|-------|--------|----------|---------------|
| C-JANUS-001 | Contracts | ActionProposal is immutable and binds belief, dynamics and canonical snapshot identity | TESTED | integration/tests/test_eig_v11.py | local V1.1 schema |
| C-JANUS-002 | FSDS/JANUS | Action-specific assessment rejects stale, insufficient, OOD, unstable and mechanism-shift states deterministically | TESTED | integration/tests/test_eig_v11.py | R-8/R-9 |
| C-JANUS-003 | PEELLL/JANUS | Evidence persistence is a prerequisite for RESERVED -> OPEN | TESTED | integration/tests/test_eig_v11.py | T15 |
| C-JANUS-004 | PEELLL/JANUS | OPEN -> CONSUMED is linearizable and exactly one consumer succeeds | TESTED | integration/tests/test_eig_v11.py | T14/T30; single-node SQLite boundary |
| C-JANUS-005 | PEELLL/JANUS | Epistemic, authorization, sensor, constraint and mechanism changes invalidate outstanding permits | TESTED | integration/tests/test_eig_v11.py | T13/T25-T29 |
| C-JANUS-006 | Integration | ALLOW alone cannot call actuator; actuator is invoked only after successful consume | TESTED | integration/tests/test_eig_v11.py; integration/runtime_pipeline.py | local reference runtime |
| C-JANUS-007 | Integration | Fallback remains separately authorized and executable under epistemic failure | TESTED | integration/tests/test_eig_v11.py | T12/T18 |
| C-JANUS-008 | Runtime | Runtime restart invalidates all RESERVED/OPEN permits | TESTED | integration/tests/test_eig_v11.py | T29; one monotonic clock domain per runtime |
| C-JANUS-009 | Runtime | Full execution lineage binds proposal, assessment, permit, evidence, commit and outcome | TESTED | integration/tests/test_eig_v11.py | T10 |


## V1.2 empirical-boundary extension

The canonical detailed V1.2 claim set is in [`CLAIM_REGISTRY_V1_2.md`](CLAIM_REGISTRY_V1_2.md). V1.2 does not alter or delete V1.1 evidence. The current promotion blocker is independent real-data source diversity (`C-DATA-004`).
