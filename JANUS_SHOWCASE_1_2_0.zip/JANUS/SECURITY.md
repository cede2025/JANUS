# SECURITY.md — JANUS ECOSYSTEM V1.1.0

## Zakres dowodu

Niniejszy dokument opisuje **zweryfikowany lokalny reference runtime**. Nie jest certyfikatem bezpieczeństwa, zgodności regulacyjnej ani pentestem.

## Sekrety

- Release nie powinien zawierać realnych sekretów użytkownika; automatyczny skan wykrywa literalne sekrety w aktywnych plikach.
- Wartości `change-me` w lokalnym compose są wyłącznie placeholderami development/reference.
- Produkcyjny/cloud secret manager jest `DEFERRED` i nie jest częścią lokalnego evidence.

## AuthN / AuthZ

- PEELLL testuje JWT oraz permission engine dla ścieżek API.
- Testy obejmują co najmniej allow / forbidden / invalid-token.
- Nie oznacza to zewnętrznego audytu IAM.

## Encryption

- Lokalny envelope szyfruje AES-GCM.
- Każdy ciphertext zawiera własny losowy salt PBKDF2 i nonce.
- Test restartu tworzy nową instancję managera i odszyfrowuje wcześniej zapisany ciphertext przy tym samym sekrecie.

## Audit

- Audit jest fail-closed na zweryfikowanej lokalnej ścieżce: błąd persistence powoduje wyjątek zamiast fałszywego sukcesu.
- Kanoniczny payload jest zapisywany wraz z HMAC-SHA256 i może zostać ponownie zweryfikowany po reconnect.
- Payload obejmuje aktora, akcję, zasób, timestamp oraz opcjonalne stare/nowe wartości i metadane klienta.
- Pełny niezależny WORM/append-only storage i zewnętrzny key management pozostają poza zakresem V1.1.0.

## Dynamical safety

`RuntimeSafetyGate` jest fail-closed contract/policy gate. Nie jest dowodem reachability, CBF/CLF ani certyfikatem safety-critical. Formalny controller jest przyszłym rozszerzeniem.

## JANUS V1.1 execution-integrity boundary

Authorization has an immutable version+digest and is bound into every permit. Authorization changes revoke dependent OPEN/RESERVED permits and are rechecked at the linearization point. Epistemic sufficiency cannot grant permission. Sensor, constraints, mechanism and policy fingerprints are also bound. Runtime restart invalidates all outstanding permits because monotonic time is valid only within one execution-authority clock domain.
