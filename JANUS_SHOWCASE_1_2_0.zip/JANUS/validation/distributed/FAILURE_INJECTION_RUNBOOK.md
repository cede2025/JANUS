# V4R Real Distributed Failure-Injection Runbook

Status in the build sandbox: **BLOCKED_ENVIRONMENT**. This document is the executable handoff for an external host; it is not evidence that the cases passed.

## Mandatory topology
- PostgreSQL 16 (real server, no SQLite substitution)
- Redis 7 with AOF and `noeviction`
- API container
- at least two Celery workers
- separate cryptographic secret roots for audit, registry, provenance, prediction, evidence, decision and execution

Start with `docker compose -f docker-compose.v4r-distributed.yml up -d --build` after exporting all required secrets in explicit `hex:` or `b64:` form. Run `python validation/distributed/probe_real_services.py`. Only status `REAL_DISTRIBUTED_ENVIRONMENT_AVAILABLE` permits the real-service suite to run.

## Baseline real-service gate
`pytest -q integration/tests/test_v4_distributed_real.py`

## Failure classes that MUST be executed
1. database unavailable before request
2. database restart during transaction
3. Redis unavailable
4. Redis restart/AOF recovery
5. worker SIGKILL before task body
6. worker SIGKILL after external dispatch but before acknowledgement
7. worker restart and task redelivery
8. service-to-service network timeout
9. broker message duplication
10. broker message loss simulation / rejected delivery
11. message reordering / stale logical sequence
12. partial database transaction and rollback
13. commit-before-ack
14. ack-before-commit attempt (must not be accepted as safe semantics)
15. stale worker with old environment/configuration fingerprint
16. duplicate proposal (same ID/same payload)
17. proposal collision (same ID/altered payload)
18. duplicate action/idempotency key
19. replayed evidence
20. forged/invalid evidence
21. checkpoint corruption
22. restart after partial state

## Evidence required per case
- exact command and injected fault
- UTC start/end timestamps
- container/service IDs and versions
- trace/correlation ID
- database transaction outcome
- queue delivery/ack state
- action-attempt count
- evidence/audit records
- recovery state
- proof of no unauthorized duplicate action
- PASS/FAIL/BLOCKED, never a silent SKIP

## Semantics rule
Do not claim exactly-once. Current intended boundary is **effectively-once where an idempotent downstream effect can be proven; otherwise fail-closed UNKNOWN / RECONCILIATION_REQUIRED with no automatic re-dispatch**.

## Release rule
Operational Readiness cannot be PASS until every release-critical case above is executed against real services and the evidence bundle is retained.
