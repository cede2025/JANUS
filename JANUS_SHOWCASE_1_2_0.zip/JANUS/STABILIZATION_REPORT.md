# STABILIZATION_REPORT.md

## What changed after the adversarial audit

1. Removed bundled fake third-party packages (`asyncpg`, `redis`, `celery`, `structlog`, `hypothesis`).
2. Added explicit local adapters: SQLite persistence, memory cache and synchronous worker fallback.
3. Encryption now stores a random PBKDF2 salt with each AES-GCM ciphertext, so a new process can decrypt with the same secret.
4. Audit is fail-closed: protected paths do not silently report success after persistence failure.
5. Added a persistent model registry and actual rollback of the active version.
6. Fixed all-false action masks by forcing a reserved fallback action.
7. Replaced the unimplemented formal-safety stub in the local path with `RuntimeSafetyGate`; it is explicitly not a CBF/CLF proof.
8. Contracts validate automatically and reject unsupported schema versions, NaN/Inf, dimension mismatches and non-PSD covariance.
9. Added a live local integration pipeline using actual FSDS + Unified Core + PEELLL persistence, not only contract mocks.
10. PEELLL packaging is made consistent with its `src.*` import namespace and is tested by wheel install.
11. Top-level FSDS duplicate modules are compatibility wrappers around the canonical `fsds_v2` implementation.
12. Added real AWS and EMA validation with retained negative results.
13. Added a finite numerical guard to CT-NLS: optimizer trial matrices that make `expm`/Fréchet evaluation non-finite receive a finite radial penalty instead of propagating NaN/Inf.

## Remaining limitations

- PostgreSQL/Redis/Celery/Kubernetes profile has not been exercised in this build environment.
- `RuntimeSafetyGate` is a fail-closed runtime policy gate, not a formal reachability/CBF certificate.
- AWS CT-NLS runs hit the configured iteration limit; fitted generators require numerical/model-selection follow-up before scientific interpretation.
- OOD stress uses a deliberately simple Mahalanobis diagnostic and tests the fallback path, not universal OOD detection.
