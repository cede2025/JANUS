# VALIDATION_REPORT_V1_2

**Wersja:** 1.2.0 empirical-boundary candidate  
**Data wykonania:** 2026-08-09  
**Primary endpoint:** paired one-step-ahead RMSE difference `RMSE_CT-NLS - RMSE_VAR_SLIDING` on chronological hold-out.  

## 1. Frozen protocol and correction audit

Finalny protokół realizuje wymaganie SPEC V1.2: split 70/30 chronologiczny, standaryzacja wyłącznie na train, `lambda=1e-3`, CT-NLS `maxiter=300`, `gtol=1e-7`, 520 pierwszych chronologicznych obserwacji panelu i 2000 replik paired moving-block bootstrap. Baseline główny to **rolling one-step Ridge VAR(1)**: przy każdym kroku testowym model jest ponownie dopasowywany wyłącznie do wcześniejszych, kompletnych przejść w oknie o długości równej początkowemu train.

Wczesny wewnętrzny draft V1.2 omyłkowo użył fixed-fit VAR. Został zachowany w `evidence/v1_2/draft_fixed_var_20260809/`, a nie nadpisany. Korekta do rolling VAR nie jest post-hoc tuningiem: wynika wprost z przekazanego SPEC i została wykonana przed finalnym release gate. Fixed-fit VAR pozostaje w wynikach jako baseline pomocniczy.

> **Boundary:** trzy wykonane panele są trzema różnymi wielowymiarowymi benchmarkami opartymi na jednym publicznym źródle Kossakowski. Nie są trzema niezależnymi źródłami. Wynik aggregate nie jest cross-source replication.

## 2. Provenance i nieregularność

Źródło: Data from: Critical Slowing Down as a Personalized Early Warning Signal for Depression (2017), DOI `10.5334/jopd.29`, licencja `CC BY 4.0`. Raw SHA-256: `8e9e6f46330859d20a13f8a58542de483f5766c75001a99066ac8ce5e114f6cd`.

| Panel | n | dim | dt CV | unique positive Δt | min h | median h | max h |
|---|---:|---:|---:|---:|---:|---:|---:|
| kossakowski_mood_irregular | 1476 | 4 | 1.131 | 1390 | 0.226 | 2.044 | 42.116 |
| kossakowski_psychomotor_irregular | 1476 | 4 | 1.131 | 1390 | 0.226 | 2.044 | 42.116 |
| kossakowski_physical_irregular | 1476 | 4 | 1.131 | 1390 | 0.226 | 2.044 | 42.116 |

## 3. CT-NLS vs rolling VAR — primary results

| Dataset | VAR sliding RMSE | VAR fixed RMSE | CT RMSE | ΔRMSE CT−VAR sliding | bootstrap 95% CI | one-sided p_boot | CT converged | iter | Verdict |
|---|---:|---:|---:|---:|---|---:|---|---:|---|
| kossakowski_mood_irregular | 0.966686 | 0.970966 | 0.984742 | +0.018056 | [-0.001144, +0.040141] | 0.9675 | True | 124 | INCONCLUSIVE |
| kossakowski_physical_irregular | 1.048104 | 1.051445 | 1.051114 | +0.003010 | [-0.013950, +0.018399] | 0.7045 | True | 118 | INCONCLUSIVE |
| kossakowski_psychomotor_irregular | 1.027234 | 1.021602 | 1.003342 | -0.023892 | [-0.052703, -0.009267] | 0.0035 | True | 55 | SUPPORTED (panel-specific CT advantage) |

### Secondary metrics

| Dataset | VAR sliding MAE | CT MAE | VAR sliding Gaussian LL | CT Gaussian LL | rolling VAR total fit s | CT fit s |
|---|---:|---:|---:|---:|---:|---:|
| kossakowski_mood_irregular | 0.789853 | 0.801875 | -744.72 | -753.21 | 0.0041 | 0.350 |
| kossakowski_physical_irregular | 0.826344 | 0.828402 | -912.43 | -915.10 | 0.0043 | 0.308 |
| kossakowski_psychomotor_irregular | 0.769388 | 0.762148 | -840.04 | -826.80 | 0.0041 | 0.135 |

## 4. Interpretation

- Panel-specific CT advantage with CI entirely below zero: **kossakowski_psychomotor_irregular**.
- Panel-specific evidence favoring rolling VAR with CI entirely above zero: **none**.
- Inconclusive panels: **kossakowski_mood_irregular, kossakowski_physical_irregular**.
- Mean ΔRMSE across the three correlated panels: `-0.000942`; aggregate status: **INCONCLUSIVE**.
- CT-NLS optimizer convergence: `100%` of executed panels.

Finalny wniosek nie brzmi „CT jest lepszy od VAR”. Jeden panel wspiera prerejestrowaną przewagę CT względem mocniejszego rolling VAR baseline, pozostałe jej nie replikują. Na obecnym jednym niezależnym źródle wynik ogólny pozostaje **INCONCLUSIVE**.

## 5. Backend and numerical equivalence

Dla praktycznego wykonania `maxiter=300` walidacja używa batched `torch.matrix_exp` + autograd dla tego samego CT-NLS objective. Każdy panel ma checkpoint porównujący loss i gradient z kanonicznym SciPy/Fréchet backendem na 24 przejściach. To zmiana backendu obliczeniowego, nie definicji estymatora.

## 6. Leakage guardrails

- split jest chronologiczny;
- mean/std są dopasowane wyłącznie na początkowym train;
- rolling VAR używa przy predykcji kroku `j` wyłącznie kompletnych przejść o indeksie `< j`;
- okno rolling VAR ma stałą długość równą liczbie początkowych kompletnych przejść train;
- test nie uczestniczy w estymacji CT ani train-only covariance;
- bootstrap jest wykonywany na sparowanych błędach hold-out, z blokami czasowymi;
- skalowanie czasu korzysta wyłącznie z mediany dodatnich train Δt i zachowuje wszystkie relacje nieregularności.

## 7. Figures

![RMSE delta versus irregularity](evidence/v1_2/rmse_delta_vs_irregularity.png)

![Stability eigenvalue versus prediction error](evidence/v1_2/stability_vs_prediction_error.png)

## 8. Independent-source replication boundary

W `PROVENANCE.json` oraz `FETCH_INDEPENDENT_DATASETS.md` zamrożono niezależne kandydaty openESM. W tym środowisku wykonawczym brak DNS, więc dodatkowych surowych plików nie zmaterializowano i **nie przypisano im żadnych wyników**. Cross-source replication pozostaje **BLOCKED**, dopóki co najmniej dwa dodatkowe niezależne źródła nie zostaną rzeczywiście pobrane, zahashowane i wykonane przez zamrożony protocol.

## 9. Epistemic verdict

- CT convergence on the three executed Kossakowski panels: **TESTED**.
- Panel-specific predictive advantage: **SUPPORTED only where the reported paired bootstrap CI is entirely below zero**.
- Universal CT predictive superiority: **REJECTED / not claimed**.
- Cross-source replication on ≥3 independent public sources: **BLOCKED**.
