Preserved pre-sliding-VAR V1.2 draft before final protocol correction.
