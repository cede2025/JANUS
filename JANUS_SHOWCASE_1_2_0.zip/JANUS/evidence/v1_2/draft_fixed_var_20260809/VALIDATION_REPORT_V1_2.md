# VALIDATION_REPORT_V1_2

**Wersja:** 1.2.0 empirical-boundary candidate  
**Data wykonania:** 2026-08-09  
**Primary endpoint:** paired one-step-ahead RMSE difference `RMSE_CT-NLS - RMSE_VAR` on chronological hold-out.  

## 1. Zakres i prerejestracja

Walidacja została zamrożona przed odczytem wyników: split 70/30 chronologiczny, standardization wyłącznie na train, `lambda=1e-3`, `maxiter=300`, `gtol=1e-7`, 520 pierwszych chronologicznych obserwacji panelu i 2000 replik paired moving-block bootstrap.

> **Boundary:** trzy wykonane panele są trzema różnymi wielowymiarowymi benchmarkami opartymi na jednym publicznym źródle Kossakowski. Nie są trzema niezależnymi źródłami. Z tego powodu wynik aggregate nie może być traktowany jako cross-dataset replication.

## 2. Provenance i nieregularność

Źródło: Data from: Critical Slowing Down as a Personalized Early Warning Signal for Depression (2017), DOI `10.5334/jopd.29`, licencja `CC BY 4.0`. Raw SHA-256: `8e9e6f46330859d20a13f8a58542de483f5766c75001a99066ac8ce5e114f6cd`.

| Panel | n | dim | dt CV | unique positive Δt | min h | median h | max h |
|---|---:|---:|---:|---:|---:|---:|---:|
| kossakowski_mood_irregular | 1476 | 4 | 1.131 | 1390 | 0.226 | 2.044 | 42.116 |
| kossakowski_psychomotor_irregular | 1476 | 4 | 1.131 | 1390 | 0.226 | 2.044 | 42.116 |
| kossakowski_physical_irregular | 1476 | 4 | 1.131 | 1390 | 0.226 | 2.044 | 42.116 |

## 3. CT-NLS vs VAR — wyniki

| Dataset | VAR RMSE | CT RMSE | ΔRMSE CT−VAR | bootstrap 95% CI | one-sided p_boot | CT converged | iter | CT fit s | Verdict |
|---|---:|---:|---:|---|---:|---|---:|---:|---|
| kossakowski_mood_irregular | 0.970966 | 0.984742 | +0.013776 | [-0.004083, +0.036013] | 0.9270 | True | 124 | 0.356 | CT WORSE / unsupported |
| kossakowski_physical_irregular | 1.051445 | 1.051114 | -0.000331 | [-0.016967, +0.013759] | 0.5615 | True | 118 | 0.304 | INCONCLUSIVE |
| kossakowski_psychomotor_irregular | 1.021602 | 1.003342 | -0.018260 | [-0.043853, -0.006024] | 0.0060 | True | 55 | 0.131 | SUPPORTED (panel-specific) |

### Interpretacja

- **Psychomotor panel:** prerejestrowana hipoteza jest wsparta w tym panelu; 95% bootstrap CI dla ΔRMSE jest całkowicie poniżej zera.
- **Mood panel:** CT ma wyższy RMSE; hipoteza przewagi nie jest wsparta.
- **Physical panel:** różnica jest praktycznie zerowa, a CI obejmuje zero.
- Średnia ΔRMSE przez trzy skorelowane panele: `-0.001605`; status aggregate: **INCONCLUSIVE**.
- CT-NLS osiągnął kryterium optymalizatora w 100% wykonanych paneli.

Wniosek nie brzmi „CT jest lepszy od VAR”. Wniosek brzmi: **na jednym rzeczywistym, intrinsically irregular źródle znalazł się jeden prerejestrowany panel, na którym CT-NLS uzyskał niższy RMSE z bootstrap CI poniżej zera; dwa inne panele nie replikują tej przewagi.**

## 4. Backend i numerical equivalence

Aby wykonać prerejestrowane `maxiter=300` w praktycznym czasie, walidacja używa batched `torch.matrix_exp` + autograd dla dokładnie tego samego CT-NLS objective. Każdy panel ma checkpoint porównujący loss i gradient z kanonicznym SciPy/Fréchet backendem na 24 przejściach; różnice są na poziomie numerycznego round-off. Nie jest to nowy estimator ani zmiana objective.

## 5. Leakage guardrails

- split jest chronologiczny;
- mean/std są dopasowane wyłącznie na train;
- test nie uczestniczy w estymacji VAR/CT ani covariance;
- bootstrap jest wykonywany na sparowanych błędach hold-out, z blokami czasowymi;
- skalowanie czasu korzysta wyłącznie z mediany dodatnich train Δt i zachowuje wszystkie relacje nieregularności.

## 6. Wykresy

![RMSE delta versus irregularity](evidence/v1_2/rmse_delta_vs_irregularity.png)

![Stability eigenvalue versus prediction error](evidence/v1_2/stability_vs_prediction_error.png)

## 7. Niezależne źródła wymagające materializacji

W `PROVENANCE.json` zapisano trzy niezależne, licencyjnie dopuszczalne kandydaty openESM (Habets 2020, Westhoff 2024, Neubauer 2024). Środowisko wykonawcze tego audytu nie posiada DNS/network, więc plików nie pobrano i **nie przypisano im wyników**. Skrypt `scripts/fetch_openesm_v1_2.py` służy do materializacji w środowisku z siecią. Dopóki co najmniej dwa dodatkowe niezależne źródła nie zostaną wykonane, cross-source replication pozostaje **BLOCKED**.

## 8. Epistemic verdict

- Panel-specific predictive advantage: **SUPPORTED for psychomotor only**.
- Universal CT superiority: **REJECTED / not claimed**.
- Cross-source replication on ≥3 independent public sources: **BLOCKED (environmental data-materialization gap)**.
- CT convergence on the three executed Kossakowski panels under frozen settings: **TESTED**.
