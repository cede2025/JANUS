Preserved pre-common-random-number / pre-stable-S1 robustness draft.
