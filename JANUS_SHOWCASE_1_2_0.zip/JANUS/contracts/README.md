# contracts/

Wspólne, wersjonowane kontrakty danych między FSDS, Unified Core i PEELLL.

Zasada: żaden projekt nie może definiować własnej, niekompatybilnej wersji tych struktur.
Wszystkie kontrakty posiadają `schema_version` i integracja odrzuca nieobsługiwaną wersję.

## JANUS V1.1 schema migration

Wire schema is `1.1.0`. Legacy protected `ActionProposal` objects without explicit dynamics and EpistemicSnapshot binding are rejected. Canonical digests use a dedicated canonicalization module; `repr`, pickle and unordered dictionary hashing are forbidden.

## Note on this evaluation artifact

The JSON Schema definitions and the Python contract/canonicalization implementation are withheld from this public repository (they define the JANUS data model in implementation-level detail). They are available for qualified technical evaluation under separate written agreement.
