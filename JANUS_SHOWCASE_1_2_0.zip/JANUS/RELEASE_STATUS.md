# JANUS Release Status

## Release

`1.2.0-EMPIRICAL_BOUNDARY_CANDIDATE`

## Verified during packaging

- FSDS tests: 36 passed.
- Unified Core tests: 106 passed.
- PEELLL local tests: 56 passed, 2 skipped.
- Integration JANUS/live/local tests: 65 passed before an external-data fixture gate.

## Known reproducibility boundary

`integration/tests/test_v2_remediation_gate.py::test_raw_intake_rejects_corrupted_online_retail_and_malformed_rows`

requires an external `/mnt/data/danne.zip` fixture that was not supplied with the public artifact. The test source remains present. The missing fixture is documented rather than bypassed.

## Empirical boundary

The V1.2 release is not `EMPIRICAL_BOUNDARY_CLOSED`. The current executed irregular-time real-data evidence is one independent public source represented by three panels. Additional independent qualifying sources are required by the frozen release protocol.

## Production boundary

The repository is a local/single-node reference runtime. PostgreSQL/Redis/Celery/Kubernetes deployment profiles are not presented as production-validated infrastructure.

## Safety boundary

The software demonstrates bounded governance and execution-integrity invariants. It is not a physical safety certificate, controller certificate, regulatory certification, or proof of safe operation of an arbitrary external system.
