# UNIFIED_E2E_REPORT_V1_2

The V1.2 loop exercises the real `UnifiedAgentV3` planner (`SubgoalPlanner`) and `EpisodicStore`, a deterministic goal-directed proposal bridge, JANUS, permit/evidence lifecycle, simulated environment side effect, outcome binding and SQLite evidence trail.

| Scenario | Status | ticks | distance | memory | evidence | outcomes | required recovery |
|---|---|---:|---:|---:|---:|---:|---|
| stable | PASS | 5 | 0.1353 | 5 | 10 | 5 | none |
| regime_shift | PASS | 6 | 0.0824 | 5 | 11 | 5 | MECHANISM_SHIFT→REIDENTIFY_MODEL |
| sensor_degradation | PASS | 6 | 0.1353 | 5 | 11 | 5 | UNOBSERVABLE→REACQUIRE_INFORMATION |
| unauthorized_action | PASS | 1 | 1.0000 | 1 | 2 | 0 | AUTHORIZATION→BLOCK |

**Boundary:** the neural policy is not being validated as a learned optimal controller. The deterministic action bridge isolates the architecture contract: planner/memory → proposal → JANUS → permit → actuation/outcome → memory/evidence.
