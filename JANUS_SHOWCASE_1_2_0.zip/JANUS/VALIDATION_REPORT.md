# VALIDATION_REPORT.md — synthetic + real data

**Release:** JANUS ECOSYSTEM V1.0.3  
**Seed:** 20260808  
**Interpretation rule:** predictive/descriptive only; no causal inference claim.

## 1. Data provenance

Real data were extracted from the user-provided `DATA AWS.zip` (SHA-256 `967b1ad0d522c9317957bcff07a37a4a88750c0ab06536738c997e0d9214483d`). The release contains small deterministic derivatives rather than the >1 GB extracted raw telemetry. Each derived sample has its own hash in `data/real_samples/PROVENANCE.json`.

AWS VM protocol: three source files; first 5 VM identifiers encountered; first 1200 5-minute CPU readings per VM; 70/30 chronological split; training-only standardization; VAR vs exact CT-NLS; fixed seed.

EMA protocol: the preregistered `fsds/real_data/EMA_PREREGISTRATION_V2.md` pipeline is additionally executed for the first 50 subjects.

## 2. Synthetic validation

Stable irregular SDE: VAR RMSE **0.6968**, CT-NLS RMSE **0.6889**; relative generator error **40.7%**. The true maximum real eigenvalue was **-0.236**, estimated **-0.281**.

This is a mixed result: the stability side is recovered, but parameter recovery is not close enough to justify a strong exact-recovery claim.

With **20.8%** synthetic missing observations, the exact Kalman negative log-likelihood stayed finite.

Regime-shift stress: true `||A2-A1||F=0.489`, estimated window shift `0.775`; estimated max-real eigenvalue changed from `-0.468` to `0.049`. This supports using operator change as a research signal, not as a universal detector.

OOD stress produced Mahalanobis score **13.07** and the runtime safety gate returned **FALLBACK**.

## 3. Real AWS VM telemetry

| Dataset | VAR RMSE | CT RMSE | CT−VAR | VAR corr | CT corr | CT optimizer success | max Re eig(A) | missing stress | OOD gate |
|---|---:|---:|---:|---:|---:|---|---:|---:|---|
| aws_vm_file_1 | 9.0081 | 8.8331 | -0.1750 | 0.293 | 0.398 | False | -0.255 | 19.6% | FALLBACK |
| aws_vm_file_2 | 2.4253 | 2.4253 | +0.0000 | 0.049 | 0.049 | False | -0.293 | 21.5% | FALLBACK |
| aws_vm_file_3 | 2.8256 | 2.8252 | -0.0003 | -0.076 | -0.075 | False | -0.080 | 18.9% | FALLBACK |

### Interpretation

- CT did **not** establish a general predictive advantage over VAR.
- In all three AWS fits, CT-NLS reached the configured 100-iteration limit without reporting optimizer convergence. The predictions remain informative as an exploratory result, but the fitted `A` should **not** be treated as a publication-grade identified generator in these runs.
- The stabilized CT-NLS includes a finite numerical guard for extreme optimizer trial matrices; the final rerun completed without `expm` overflow/NaN warnings. This guard improves numerical containment but does not turn non-converged AWS fits into identified models.
- Missing-data stress remained numerically finite under the Gaussian likelihood.
- Deliberately generated OOD stress states produced `FALLBACK` in all three datasets. This tests the fail-closed runtime path; it does not prove universal OOD detection.

## 4. Real EMA — preregistered 50-subject validation

Primary mean `RMSE_CT - RMSE_VAR` = **-0.000939**. 95% bootstrap CI = **[-0.002596, +0.000274]**. CT was better in **42%** of held-out subjects.

**Conclusion:** the interval crosses zero. This result is inconclusive and does not support a claim that CT-NLS is generally superior to VAR on this dataset.

## 5. What is actually demonstrated

1. The linear-SDE simulation, CT-NLS, VAR baseline, Kalman likelihood, missingness path and runtime safety fallback execute reproducibly.
2. Real-data processing is not limited to synthetic test fixtures.
3. Negative results are retained.
4. The current AWS CT-NLS configuration requires further numerical/model-selection work before interpreting `A` scientifically.

## 6. What is not demonstrated

- causal effects;
- universal superiority of continuous-time estimation;
- universal OOD detection;
- safety certification;
- production SLA;
- generalization to all cloud workloads or clinical populations.

## 7. Reproduction

Run `./RUN_VALIDATION.sh` for the standard reproducibility profile. It evaluates all three bundled AWS VM samples (prediction + missingness + OOD) and then runs the preregistered EMA N=50 pipeline separately. Run `./RUN_VALIDATION_FULL.sh` for the slower extended research profile that additionally repeats first/last-half mechanism-drift fits and the small exploratory EMA loop. The large original `DATA AWS.zip` is not required because hashed derived samples are bundled. To reconstruct the samples from the original archive, use `scripts/extract_aws_samples.py` (if the full archive is available).
