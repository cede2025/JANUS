# START HERE

This is an **evaluation artifact**, not a runnable package. There is no code to install or execute in this repository — no `START_HERE.sh`/`.bat`, no `INSTALL_LOCAL`, no `RUN_VALIDATION` scripts, because the source they would run is not included here.

## What you can do with this repository

1. Read `README.md` for what JANUS is and what it does/does not claim.
2. Read `CLAIM_REGISTRY_V1_2.md` and `RELEASE_GATE_V1_2.md` for the current status.
3. Read `VALIDATION_REPORT_V1_2.md` and browse `evidence/` for the underlying logs, figures and result traces backing those claims.
4. Read `REPRODUCIBILITY.md` for a process-level description of how the validation protocol was executed (not the implementation itself).

## What this demo would have shown, at a process level

The (withheld) local reference runtime runs the same logical flow on synthetic data and on the bundled real AWS telemetry sample:

`observation → FSDS dynamics/belief → Unified action proposal → runtime safety gate → audit/persistence`

It performs no real actions against external systems.

## Requesting source access

Source code, the JANUS mechanism specification, and the technical monograph are available for qualified technical evaluation under separate written agreement. See `SECURITY.md`.

## Important limitation

The evidence in this repository is stabilized for a **local/single-node reference runtime**. The Postgres/Redis/Celery/Kubernetes profile is an optional cloud profile that would require separate infrastructure validation. The system is not certified for medical, aviation, or other safety-critical use.
