# Independent irregular datasets — V1.2 fetch protocol

This directory already contains three executed, intrinsically irregular multivariate benchmark panels derived from the public Kossakowski 2017 source. They are **not independent source replications**.

For source-diverse replication, V1.2 preregisters the following openESM harmonized datasets:

| ID | Study | Sampling | Raw timestamp | License | Suggested variables |
|---|---|---|---|---|---|
| `0014_habets` | Habets 2020 | 7/day semi-random | yes | CC0 1.0 | `well, down, frightened, tense` |
| `0008_westhoff` | Westhoff 2024 | 5/day semi-random | yes | CC BY 4.0 | `negative_affect_behavior, positive_affect_behavior, negative_cognition_behavior, positive_cognition_behavior` |
| `0062_neubauer` | Neubauer 2024 | 6/day semi-random | yes | CC BY 4.0 | `happy, afraid, sad, balanced` |

All three have >500 observations in aggregate across participants and licenses allowing academic and commercial reuse subject to attribution where required.

## Why they are not bundled in the current artifact

The execution container used to construct this release has no DNS/network access. No result is fabricated for a dataset that was not materialized. This is recorded as `BLOCKED_SOURCE_DIVERSITY`, not silently converted to a PASS.

## Fetch in a network-enabled environment

1. Create/activate a research environment.
2. Install the optional client:

```bash
python -m pip install openesm pandas numpy
```

3. Run:

```bash
python scripts/fetch_openesm_v1_2.py
```

The script stores raw/harmonized exports under `data/real_samples_v1_2/openesm_raw/`, computes SHA-256, writes per-source provenance, and refuses to mark a dataset READY unless:

- the declared license is allow-listed (`CC0`, `CC BY`),
- a raw timestamp column exists,
- at least three selected dynamic variables exist,
- at least 500 total rows are available,
- positive within-subject Δt has more than one unique value.

## Modeling rule for multi-participant datasets

Never create transitions across participant boundaries. A source-wide CT-NLS/VAR comparison must pool **within-subject transitions only**. The chronological 70/30 split is defined within each participant; standardization parameters are fitted from the union of training observations only. This is a different data geometry than a single long trajectory and must be reported as such.

## Status

Until at least two of these independent sources have been materialized and evaluated in addition to Kossakowski, the claim `cross-source replication across >=3 independent public irregular datasets` remains **BLOCKED**.
