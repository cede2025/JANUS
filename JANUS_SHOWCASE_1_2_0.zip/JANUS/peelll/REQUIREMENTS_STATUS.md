# PEELLL dependency status

Full test/runtime requires packages not guaranteed in clean reproduce environment:

- asyncpg, sqlalchemy, redis — persistence
- structlog — logging
- statsmodels — VAR
- scikit-learn — anomaly utilities
- hypothesis — property tests
- httpx — API tests (ASGITransport)
- cryptography, PyJWT, pydantic, fastapi, uvicorn, prometheus-client

Until these are installed (or provided via environment.yml / docker compose), PEELLL tests are **BLOCKED**, not PASS.

Set `PEELLL_SKIP_DB_LIFESPAN=1` for routes that must not touch DB at import/startup.
