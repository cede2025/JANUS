# PEELLL — Operational Platform V1

**Version:** 1.0.0  
**Status:** RESEARCH_CANDIDATE (operational platform core)  
**Role (SPEC-012):** API, ingestion, storage, queues, authentication, authorization, audit, model registry, evidence registry, deployment, monitoring, operational governance.

## What PEELLL is

PEELLL is the operational shell around FSDS and Unified Core. It owns:

- HTTP API (versioned request/response schemas)
- Persistence of events, belief states, model versions, safety decisions, audit records
- AuthN / AuthZ (JWT + RBAC)
- Model registry with status lifecycle (CANDIDATE → SHADOW → APPROVED → PRODUCTION → RETIRED)
- Evidence / audit trail

## What PEELLL is NOT (SPEC-005, SPEC-086, SPEC-170)

- Not a causal inference platform
- Not formally verified
- Not mathematically proven end-to-end
- No claimed 99.9% SLA or 2000 req/s without measured soak/benchmark evidence
- Not a substitute for FSDS dynamical theory

VAR / anomaly / CUSUM remain as **baseline analytics / monitoring utilities** only.

## Runtime dependencies

PEELLL requires (see `requirements.txt` / lock):

- asyncpg, sqlalchemy, redis, structlog, PyJWT, cryptography, pydantic, httpx, statsmodels, …

Integration tests that need real PostgreSQL/Redis are **BLOCKED** when infrastructure is absent. They must not be reported as PASS.

## Tests

```bash
# unit (may still need some deps)
python3 -m pytest tests/unit -q --override-ini="addopts="

# integration — only when DB/Redis available, else mark BLOCKED
PEELLL_SKIP_DB_LIFESPAN=1 python3 -m pytest tests/integration -q --override-ini="addopts="
```

## Status honesty

Until:

1. all declared deps are locked and installable,
2. unit + integration tests pass in a clean environment (or are explicitly BLOCKED),
3. no forbidden claims remain in active docs,

PEELLL remains **RESEARCH_CANDIDATE**, not PRODUCTION.
