# Security Documentation

**Document ID:** SEC-001  
**Version:** 1.0.0

## Threat Model

### STRIDE Analysis

| Threat | Component | Mitigation |
|--------|-----------|------------|
| Spoofing | API Auth | JWT + mTLS |
| Tampering | Data in transit | TLS 1.3 |
| Repudiation | Audit logs | HMAC-signed, immutable |
| Information Disclosure | Database | AES-256-GCM at rest |
| Denial of Service | API Gateway | Rate limiting + WAF |
| Elevation of Privilege | RBAC | Least privilege + regular audit |

## Penetration Test Results

**Date:** 2026-07-15  
**Vendor:** RedTeam Security  
**Scope:** Full application + infrastructure

### Findings

| Severity | Count | Status |
|----------|-------|--------|
| Critical | 0 | N/A |
| High | 1 | Remediated (CORS misconfiguration) |
| Medium | 2 | Remediated (Information disclosure in error messages) |
| Low | 3 | Accepted (Informational headers) |

## Encryption Details

### At Rest
- Algorithm: AES-256-GCM
- Key rotation: 90 days
- Key storage: Vault

### In Transit
- Protocol: TLS 1.3
- Cipher suites: TLS_AES_256_GCM_SHA384, TLS_CHACHA20_POLY1305_SHA256
- Certificate: Let's Encrypt, auto-renewal

## Audit Requirements

All access to PII triggers an audit log entry containing:
- User ID
- Action (READ/WRITE/DELETE)
- Resource ID
- Timestamp (UTC)
- IP Address
- User Agent
- HMAC signature

Retention: 7 years (regulatory requirement)
