# Deployment Guide

**Document ID:** DEP-001  
**Version:** 1.0.0

## Prerequisites

- Kubernetes 1.28+
- Helm 3.12+
- Docker 24+
- kubectl configured for target cluster
- Vault access

## Infrastructure Setup

```bash
# 1. Create namespace
kubectl create namespace peelll-production

# 2. Install dependencies (PostgreSQL, Redis, Vault)
helm repo add bitnami https://charts.bitnami.com/bitnami
helm repo add hashicorp https://helm.releases.hashicorp.com

helm install postgres bitnami/postgresql-ha -n peelll-production -f k8s/postgres-values.yaml
helm install redis bitnami/redis-cluster -n peelll-production -f k8s/redis-values.yaml
helm install vault hashicorp/vault -n peelll-production -f k8s/vault-values.yaml

# 3. Configure Vault
kubectl exec -it vault-0 -n peelll-production -- vault operator init
kubectl exec -it vault-0 -n peelll-production -- vault operator unseal

# 4. Deploy application
kubectl apply -k k8s/overlays/production/

# 5. Verify
kubectl get pods -n peelll-production
kubectl get svc -n peelll-production
```

## Environment Variables

| Variable | Description | Secret? |
|----------|-------------|---------|
| DATABASE_URL | PostgreSQL connection string | Yes |
| REDIS_URL | Redis connection string | Yes |
| VAULT_ADDR | Vault endpoint | No |
| VAULT_TOKEN | Vault auth token | Yes |
| AWS_ACCESS_KEY_ID | S3 access | Yes |
| AWS_SECRET_ACCESS_KEY | S3 secret | Yes |
| JWT_SECRET | Token signing key | Yes |
| MODEL_REGISTRY_PATH | S3 path for models | No |

## Rollback Procedure

```bash
# Rollback deployment
kubectl rollout undo deployment/api-gateway -n peelll-production

# Rollback database (if migration failed)
alembic downgrade -1

# Rollback model
kubectl set image deployment/inference-worker model=registry/peelll:PREVIOUS_VERSION
```
