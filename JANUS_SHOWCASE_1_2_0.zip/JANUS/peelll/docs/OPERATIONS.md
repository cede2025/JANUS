# Operations Manual & Runbooks

**Document ID:** OPS-001  
**Version:** 1.0.0  
**Owner:** SRE Team

---

## 1. Incident Severity Levels

| Level | Name | Response Time | Example |
|-------|------|---------------|---------|
| SEV-1 | Critical | 15 min | Complete outage, data loss |
| SEV-2 | High | 1 hour | Performance degradation > 50% |
| SEV-3 | Medium | 4 hours | Single model failure, non-critical drift |
| SEV-4 | Low | 24 hours | Documentation issue, minor alert |

---

## 2. Runbook: Total Outage (SEV-1)

### 2.1 Detection
- PagerDuty alert: "peelll-prod availability < 99.9%"
- Grafana dashboard: "API Error Rate > 1%"

### 2.2 Immediate Actions (< 5 min)

```bash
# 1. Check pod status
kubectl get pods -n peelll-production

# 2. Check recent events
kubectl get events -n peelll-production --sort-by='.lastTimestamp' | tail -20

# 3. Check database connectivity
kubectl exec -it deploy/postgres-primary -n peelll-production -- psql -U peelll -c "SELECT 1"

# 4. Check Redis
kubectl exec -it deploy/redis-master -n peelll-production -- redis-cli ping
```

### 2.3 If Database is Down

```bash
# 1. Promote read replica to primary
kubectl exec -it sts/postgres-replica -n peelll-production --   pg_ctl promote -D /var/lib/postgresql/data

# 2. Update service endpoint
kubectl patch service postgres-service -n peelll-production   --patch '{"spec": {"selector": {"role": "promoted-primary"}}}'

# 3. Verify connectivity
psql -h postgres-service.peelll-production.svc -U peelll -c "SELECT pg_is_in_recovery();"
# Expected: f (false = primary)
```

### 2.4 If API Pods are CrashLooping

```bash
# 1. Check logs
kubectl logs -l app=api-gateway -n peelll-production --tail=100

# 2. Common causes:
#    - Vault secret unavailable: Check Vault status, unseal if needed
#    - OOMKilled: Increase memory limit in deployment
#    - Liveness probe failing: Check dependency health

# 3. Rollback to last known good image
kubectl set image deployment/api-gateway   api=registry/peelll:LAST_KNOWN_GOOD_TAG -n peelll-production

# 4. Monitor rollout
kubectl rollout status deployment/api-gateway -n peelll-production
```

### 2.5 Communication

```
1. Post in #incidents Slack channel
2. Create incident in PagerDuty
3. Update status page if user-facing
4. Every 30 min: Status update to stakeholders
```

---

## 3. Runbook: Model Degradation (SEV-2)

### 3.1 Symptoms
- Grafana: `model_accuracy` dropped below 0.85 for 5 minutes
- Alert: `concept_drift W_distance > τ_drift`

### 3.2 Diagnostic Steps

```bash
# 1. Check current model version
curl https://api.peelll.ai/v1/models | jq '.[] | select(.status=="production")'

# 2. Check drift metrics
curl https://api.peelll.ai/v1/monitoring/drift | jq

# 3. Check prediction latency
curl https://api.peelll.ai/v1/monitoring/metrics | grep prediction_latency
```

### 3.3 Automatic Response (if configured)
- System triggers retraining pipeline
- Canary deployment with 10% traffic
- Automatic rollback if canary accuracy < threshold

### 3.4 Manual Rollback

```bash
# Rollback to previous production version
curl -X POST https://api.peelll.ai/v1/admin/rollback   -H "Authorization: Bearer $ADMIN_TOKEN"   -d '{"target_version": "1.2.8", "reason": "Accuracy degradation in 1.3.0"}'

# Verify rollback
curl https://api.peelll.ai/v1/models | jq '.[] | select(.status=="production")'
```

---

## 4. Runbook: Data Recovery

### 4.1 Backup Verification

```bash
# Daily backup check
ls -la /backups/postgres/$(date +%Y-%m-%d)/
# Expected: peelll-backup-$(date +%Y-%m-%d).sql.gz

# Backup integrity test
gunzip -t /backups/postgres/$(date +%Y-%m-%d)/peelll-backup-*.sql.gz
```

### 4.2 Point-in-Time Recovery

```bash
# 1. Stop application
kubectl scale deployment api-gateway --replicas=0 -n peelll-production

# 2. Restore from backup
pg_restore --clean --if-exists   --dbname=peelll   /backups/postgres/YYYY-MM-DD/peelll-backup-YYYY-MM-DD.sql.gz

# 3. Replay WAL archives (if PITR is configured)
pg_basebackup -D /var/lib/postgresql/recovery -X stream -P

# 4. Verify data consistency
psql -U peelll -c "SELECT COUNT(*) FROM events;"
psql -U peelll -c "SELECT COUNT(*) FROM predictions;"

# 5. Restart application
kubectl scale deployment api-gateway --replicas=3 -n peelll-production
```

### 4.3 Object Store Recovery

```bash
# Sync from backup bucket
aws s3 sync s3://peelll-backups/models/ s3://peelll-production/models/   --profile disaster-recovery

# Verify model artifacts
aws s3 ls s3://peelll-production/models/ --recursive | wc -l
```

---

## 5. Runbook: Security Incident

### 5.1 Suspected Data Breach

```bash
# 1. Isolate affected pods
kubectl label pods -l app=api-gateway -n peelll-production isolation=quarantine

# 2. Capture forensic logs
kubectl logs -l app=api-gateway -n peelll-production --since=24h > /forensics/logs-$(date +%s).txt

# 3. Rotate all secrets
vault operator rotate
kubectl rollout restart deployment -n peelll-production

# 4. Audit log analysis
psql -U peelll -c "
  SELECT user_id, action, resource, timestamp, ip_address 
  FROM audit_logs 
  WHERE timestamp > now() - interval '24 hours'
  ORDER BY timestamp DESC;
"

# 5. Notify security team and legal
```

---

## 6. Maintenance Windows

### 6.1 Scheduled Maintenance Procedure

```
1. Announce 48 hours in advance (status page + email)
2. Enable maintenance mode: return 503 with Retry-After header
3. Scale down non-critical workers
4. Execute maintenance (DB migration, config update, etc.)
5. Run smoke tests
6. Disable maintenance mode
7. Monitor for 1 hour
8. Close maintenance window
```

### 6.2 Database Migration

```bash
# Pre-migration backup
make backup

# Run migration with dry-run first
alembic upgrade head --sql > /tmp/migration.sql

# Review migration
less /tmp/migration.sql

# Execute
alembic upgrade head

# Post-migration verification
make test-integration
```

---

## 7. Escalation Matrix

| Issue | Primary | Escalation L1 | Escalation L2 |
|-------|---------|---------------|---------------|
| Infrastructure | SRE On-call | SRE Lead | CTO |
| Model/ML | ML Engineer | ML Lead | Chief Scientist |
| Security | Security Engineer | CISO | CTO |
| Data | Data Engineer | Data Lead | CTO |

---

## 8. SLAs & SLOs

| Metric | SLO | SLA | Measurement |
|--------|-----|-----|-------------|
| Availability | 99.95% | 99.9% | Uptime monitoring |
| P95 Latency | 150ms | 200ms | Prometheus histogram |
| P99 Latency | 300ms | 500ms | Prometheus histogram |
| Error Rate | 0.1% | 0.5% | API gateway logs |
| MTTR | 30 min | 1 hour | Incident tracking |
| MTBF | 720 hours | 168 hours | System logs |

---

**Document End.**
