# RELEASE NOTES - V1.1.0 EPISTEMIC_INTEGRITY_CLOSED

V1.1.0 closes the assessment and execution TOCTOU gaps identified after V1.0.3.

Key changes:
- schema bump to 1.1.0;
- immutable BeliefState, DynamicsEstimate, ActionProposal and EpistemicSnapshot digests;
- action-specific observability/identifiability and model-uncertainty checks;
- canonical MechanismAttestation;
- deterministic EpistemicValidityAssessment and recovery mapping;
- immutable ExecutionPermit payload plus separate mutable lifecycle;
- RESERVED -> OPEN only with durable EvidenceRecord;
- SQLite `BEGIN IMMEDIATE` linearizable local execution commit;
- full snapshot, sensor, constraints, mechanism and authorization freshness checks;
- monotonic clock-domain binding and restart invalidation;
- no soft-refresh API;
- one proposal may not create multiple execution permits;
- T1-T30, including 32- and 100-consumer concurrency tests;
- live local pipeline now executes through proposal -> assessment -> evidence -> permit -> consume -> actuator -> outcome.

Prohibited claims remain prohibited.
