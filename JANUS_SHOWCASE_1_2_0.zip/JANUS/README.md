# JANUS — Epistemic Integrity & Governed Decision Runtime (Evaluation Artifact)

JANUS is a research-grade reference implementation for governed AI/agent execution. It separates:

`observation → state/belief → dynamics → prediction → reliability assessment → safety/governance decision → controlled execution → evidence`

**This is an evaluation artifact, not a source-disclosure release.** It contains the release documentation, validation protocols, results, evidence logs, and reproducibility reports for JANUS. The runnable implementation (FSDS estimators, the Epistemic Integrity Gate mechanism, PEELLL execution/audit layer, Unified Core agent) is not included here. Access to source for technical due diligence is available under separate written agreement — see `SECURITY.md` and the "Requesting source access" section below.

## Current release status

**1.2.0-EMPIRICAL_BOUNDARY_CANDIDATE**

The V1.1 epistemic execution-integrity boundary is closed for the documented **local/single-node reference runtime**.

The V1.2 empirical boundary is intentionally **not** claimed closed. The current empirical validation uses one independent public source represented by three irregular-time panels. Promotion requires execution of the frozen protocol on additional independent qualifying sources.

This distinction is deliberate: negative and inconclusive results are retained rather than converted into positive claims.

## What JANUS demonstrates

- immutable, canonical decision contracts;
- proposal-to-assessment binding to an exact epistemic snapshot;
- commit-time revalidation of epistemic state and authorization;
- fail-closed audit/evidence persistence;
- single-consume execution semantics within the local execution authority;
- explicit fallback behavior;
- deterministic evidence lineage;
- formal continuous-time state/dynamics primitives;
- reproducible empirical validation protocols;
- bounded robustness experiments for the JANUS enforcement path.

Evidence for each of these claims is in `evidence/`, result traces under `unified_core/results/`, and the claim registries below — not in inspectable source in this repository.

## What JANUS does not claim

This repository is **not** a certification of physical safety, causal identification, AGI, universal OOD detection, universal crisis detection, CT superiority over VAR, cloud availability/SLA, or safety-critical regulatory compliance.

The robustness results measure the documented `monitor + decision-gate` harness. They do not establish that the decision-gate alone detects arbitrary regime changes from raw observations.

## What's in this repository

- `docs/` — architecture summaries and reproducibility material (implementation-level specs withheld, see below).
- `evidence/` — retained validation evidence, logs, figures and result traces.
- `data/` — real and synthetic validation samples with provenance records.
- `deployment/` — infrastructure profiles (Docker/Kubernetes) for reference only; not equivalent to production validation.
- Release notes, claim registries, validation and stabilization reports at the repository root.

## What's intentionally withheld

- All source code (FSDS estimators, JANUS mechanism, PEELLL execution/audit layer, Unified Core agent, integration pipeline, contracts implementation and JSON schemas).
- Documents that describe the JANUS mechanism, contract data model, or estimator mathematics in implementation-level detail (formal proofs, specs, the technical monograph).
- SQLite evidence databases whose schema exposes the JANUS persistence model.
- Raw per-trial evidence (logs, CSVs, execution traces) and any config/protocol file stating exact hyperparameters or operating thresholds — kept as short PASS/FAIL/FALSIFIED summaries instead (see `CLAIM_REGISTRY_V1_2_SUMMARY.md`).

These are available for qualified technical evaluation under a separate written agreement.

## Reproducibility note

This public artifact does not include runnable code, so the validation numbers below are reported, not independently re-runnable by a reader of this repository. Reviewers with source access can reproduce them via the internal `reproduce.sh` / `RUN_VALIDATION_V1_2.sh` protocol described (at a process level, not implementation level) in `REPRODUCIBILITY.md`.

Independently executed local suites verified during packaging (see `evidence/release/` logs for details):

- FSDS: **36 passed**
- Unified Core: **106 passed**
- PEELLL local suite: **56 passed, 2 skipped**
- Integration suite: **65 passed before the external-fixture gate**

One integration gate (`test_raw_intake_rejects_corrupted_online_retail_and_malformed_rows`) depends on an external fixture not included in any release and is reported as such rather than silently dropped.

## Security boundary

See `SECURITY.md`. The repository contains no production secrets.

## License

No open-source license is granted by this repository. The material is published for technical inspection and evaluation only. Redistribution, commercial use, and derivative publication require written permission from the rights holder. See `LICENSE`.

## Recommended evaluation path

1. Read this README and `SECURITY.md`.
2. Review `CLAIM_REGISTRY_V1_2_SUMMARY.md` (redacted — the full registry with exact JANUS operating parameters is withheld from this showcase, see the summary for why).
3. Review `VALIDATION_REPORT_V1_2.md` and the evidence under `evidence/`.
4. Review `REPRODUCIBILITY.md` for the process-level protocol description.
5. For source-level review (JANUS mechanism, FSDS estimators, contracts), request access under NDA.

## Integrity principle

JANUS deliberately distinguishes **epistemic sufficiency** from **authorization**, and **authorization** from **execution**.

`ALLOW` is a governance decision. It is not itself an actuator capability.
