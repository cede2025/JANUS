# REPRODUCIBILITY.md — JANUS ECOSYSTEM V1.2.0 EMPIRICAL BOUNDARY CANDIDATE

## Minimalne wymagania dla profilu lokalnego

- Python 3.11+;
- zalecane 8 GB RAM;
- dostęp do internetu tylko przy pierwszej instalacji zależności przez `INSTALL_LOCAL`.

Docker **nie jest wymagany** do uruchomienia ani pełnej reprodukcji profilu lokalnego. Opcjonalny `docker-compose.yml` uruchamia pojedynczy reference API, ale Docker nie był dostępny w środowisku budowy i dlatego sam image build pozostaje `DEFERRED`.

## Dla osoby nietechnicznej

1. Uruchom `INSTALL_LOCAL.bat` (Windows) albo `./INSTALL_LOCAL.sh` (macOS/Linux) jeden raz.
2. Następnie używaj `START_HERE.bat` / `START_HERE.command` / `./START_HERE.sh`.
3. Skrypty automatycznie używają lokalnego `.venv`; ręczna aktywacja nie jest potrzebna.

## Pełna reprodukcja

macOS/Linux:

```bash
./reproduce.sh
```

Windows:

```text
REPRODUCE.bat
```

Pipeline wykonuje środowisko, compile check, testy trzech projektów, testy integracyjne, jawny regresyjny T1–T30, live demo, syntetyczną walidację, real-data AWS, EMA N=50, V1.2 irregular real-data validation, JANUS robustness, Unified Core E2E, claim/security/manifest checks i smoke test. Cięższe zadania naukowe są uruchamiane sekwencyjnie, aby wynik nie zależał od przypadkowej konkurencji BLAS/PyTorch/SciPy o zasoby procesu.

Wyniki uruchomienia trafiają do `runtime_output/`. Referencyjne wyniki z budowy release znajdują się w `evidence/` i `VALIDATION_REPORT.md`.

## Dane realne

Release zawiera deterministyczne, hashowane próbki wyprowadzone z `DATA AWS.zip`, więc pełny >1 GB ekstrakt nie jest potrzebny do reprodukcji. `data/real_samples/PROVENANCE.json` dokumentuje pochodzenie i SHA-256. Jeżeli oryginalne archiwum jest dostępne, `scripts/extract_aws_samples.py` może odtworzyć próbki.

## Manifest

- manifest skrótów SHA256 obejmuje statyczne pliki release (nie dołączony do tej paczki ewaluacyjnej);
- `runtime_output/`, cache i artefakty build są celowo wyłączone;
- `scripts/validate_release.py --manifest` weryfikuje integralność statycznego release.

## Profile poza zakresem dowodu

PostgreSQL/Redis/Celery/Kubernetes pozostają profilem opcjonalnym i wymagają osobnej walidacji infrastrukturalnej, soak testu i pomiarów SLA.

---

## V1.2 empirical validation profile

The V1.2 candidate adds:

```bash
./RUN_VALIDATION_V1_2.sh
```

This executes the bundled intrinsically-irregular Kossakowski panels, the 900-trial JANUS robustness harness, the four Unified Core E2E scenarios, and regenerates V1.2 reports.

`./reproduce.sh` runs the V1.2 experiments into `runtime_output/v1_2/` so canonical release evidence is not overwritten during reproduction.

### Independent-source closure

`data/real_samples_v1_2/FETCH_INDEPENDENT_DATASETS.md` and `scripts/fetch_openesm_v1_2.py` define a frozen optional network step for three independent openESM sources. Once at least two additional sources are materialized, run `experiments/v1_2/validate_openesm_multisubject.py` and then `scripts/check_v12_empirical_gate.py`. The gate counts a source only when qualifying materialized provenance **and** a completed frozen validation file are both present; metadata-only candidates never count.

Until the gate reports ≥3 independently executed sources, the correct label is `EMPIRICAL_BOUNDARY_CANDIDATE`, not `CLOSED`.
