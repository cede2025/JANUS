# Deprecated legacy benchmarks

These files are retained only for provenance. They are **not** accepted as evidence for FSDS v2.
Known audit failures include: direct reading of ground-truth eigenvalues in the stability test,
Digital Twin data generated independently of its declared A matrix, missing values replaced by zero,
and a cascade benchmark without a prospective leverage->future-cascade target.

Use `benchmarks_v2/` for all v2 evidence.
