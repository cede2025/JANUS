# FSDS v2 Release Gate

| Gate | Status | Evidence |
|---|---|---|
| Declared CT-NLS objective implemented with individual dt | PASS | implementation source (withheld from this evaluation package), unit tests |
| No primary `log(Phi)/mean(dt)` estimator | PASS | source scan test |
| No silent complex-to-real matrix-log hack | PASS | checked diagnostic returns `NON_REAL_GENERATOR` |
| Stable matrix exponential path without eigenvector inversion | PASS | Schur + scaling/squaring reference; near-Jordan test |
| Exact transition covariance | PASS | Van Loan implementation + scalar closed-form test |
| Explicit row/column orientation | PASS | VAR orientation test; Rust `Orientation` API |
| Irregular dt supported | PASS | CT-NLS and Rust objective retain all dt values |
| Missing data represented as NaN, not zero | PASS | CT likelihood/Kalman test + benchmark |
| New benchmarks measure actual recovery | PASS | `benchmarks_v2/` uses explicit ground-truth A |
| Stability benchmark fits a model | PASS | no direct ground-truth eigvalue substitution |
| Cascade attribution corrected | PASS | local model renamed; Motter-Lai isolated as reference |
| CSD renamed / false-alarm benchmark included | PASS | Critical Transition Indicators + null benchmarks |
| Real EMA N>=50 preregistered LOPO | PASS | 50-person frozen protocol and result file |
| One-command Python reproduction | PASS | `reproduce.sh` |
| Negative/inconclusive outcomes retained | PASS | quick stability/CSD and EMA results are reported as such |
| Claims categorized | PASS | `FSDS_CLAIM_REGISTRY_V2.md` |
| Rust compile/test verified in construction environment | **BLOCKED** | `cargo` / `rustc` unavailable |

## Promotion rule

The label **FSDS v2.0 final** is blocked until the Rust crate compiles and all four required Rust tests pass under the locked dependency set. Until then the correct label is **FSDS v2.0 Research Candidate (RC1)**.
