# Migration from prototype lineage to FSDS v2

## Removed from the scientific core

- universal superiority of CT-VAR over VAR;
- universal CSD/crisis detector language;
- attribution of the local cascade engine to classical Motter-Lai;
- causal-inference language based only on A/VAR coefficients;
- AGI, production-ready and SLA claims as scientific evidence;
- “formal verification” wording for ordinary tests;
- proof-of-world-dynamics / universal-law / proof-of-interdisciplinarity language;
- matrix-log `take(real)` behavior;
- `mean(dt)` substitution as an irregular-time estimator.

## Replaced by

- explicit SDE assumptions;
- exact transition mean and covariance;
- separate stability, stationarity and prediction questions;
- VAR baseline, CT-NLS and CT Gaussian likelihood as distinct estimators;
- matrix-function safety diagnostics;
- benchmark targets generated from explicit ground truth;
- empirical uncertainty and held-out evaluation;
- a claim registry that distinguishes mathematical statements from empirical support.
