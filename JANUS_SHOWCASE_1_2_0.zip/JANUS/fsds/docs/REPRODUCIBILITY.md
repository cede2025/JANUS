# Reproducibility policy

The v2 reproduction unit consists of source code, locked Python versions, Rust lockfile, source-data hashes, fixed seeds, preregistered EMA protocol and generated result JSON files.

A file hash manifest covers all non-result source/protocol/data files except itself, verified before execution. Not included in this evaluation package.

The attached EMA source is retained because it is small enough to make the scientific gate self-contained. Large VM telemetry from the audit is not copied into v2 because it is not required for the v2 acceptance criteria.

Random seeds used by the benchmark suite and EMA bootstrap are fixed to `20260807` unless a benchmark explicitly records another seed.
