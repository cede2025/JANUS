# FSDS v2.0 Research Candidate

**Formalizm Sieciowej Dynamiki Stanów — scientific hardening fork**

FSDS v2 is a research framework for representing and evaluating finite-dimensional multivariate dynamics. It is deliberately narrower than the prototype lineage: it does **not** claim a universal law, universal crisis detection, causal identification from temporal coefficients, guaranteed superiority over VAR, production readiness, AGI capability, or formal verification.

The governing principle is:

> Mathematical correctness first; implementation second; validation third; interpretation last.

## Core model

\[
dX_t = A X_t\,dt + G\,dW_t,
\]

with exact transition

\[
X_{t+\Delta}=e^{A\Delta}X_t+\eta_\Delta,
\qquad
Q_\Delta=\int_0^\Delta e^{As}GG^Te^{A^Ts}\,ds.
\]

The project uses the **column-vector convention** throughout the mathematical API. Row-stored observational data are transposed explicitly when estimating transition operators.

## Estimator stack

1. **Ridge VAR** — baseline, never treated as inferior by definition.
2. **Exact CT-NLS** — minimizes the declared individual-`Delta t` nonlinear objective with L-BFGS-B and an analytic Frechet gradient.
3. **Full Gaussian CT likelihood** — low-dimensional continuous-discrete Kalman reference implementation using exact transition covariance and `NaN`-aware measurement updates.

`A = log(Phi)/mean(dt)` is banned as the primary estimator. Matrix logarithms are diagnostic only and are never repaired by silently taking the real part.

## Repository map

- `FSDS_CLAIM_REGISTRY_V2.md` — frozen epistemic registry.
- `docs/MATHEMATICAL_SPEC.md` — mathematical specification and assumptions.
- `docs/FSDS_V2_TECHNICAL_REPORT.md` — methods, results, limitations and comparison with existing work.
- `docs/RELEASE_GATE.md` — machine-checkable release status.
- `fsds_v2/` — Python reference implementation.
- `fsds_v2/matrix_functions/` — Schur/scaling-and-squaring exponential, covariance, checked diagnostic log.
- `benchmarks_v2/` — ground-truth recovery benchmarks.
- `critical_transition/` — descriptive Critical Transition Indicators, not a crisis detector.
- `cascade/` — FSDS local overload model plus a separate Motter-Lai reference implementation.
- `real_data/` — frozen EMA protocol and supplied source data used by the v2 gate.
- `rust_ctvar_v2/` — rewritten Rust reference source with explicit orientation and irregular-`dt` objective.
- `deprecated/legacy_benchmarks/` — retained only for provenance; excluded from evidence.

## Reproduction

```bash
./reproduce.sh
```

The command verifies the source manifest, runs Python tests, v2 quick benchmarks, the frozen 50-person EMA LOPO analysis, rebuilds the technical report, and attempts Rust tests when `cargo` is available.

A missing Rust toolchain does not become a silent pass. It leaves the package at **research-candidate** status.

For heavier Monte Carlo / CT-likelihood benchmarks:

```bash
PYTHONPATH=. python -m benchmarks_v2.run_all --out results/benchmarks_v2_full.json
```

## Scientific interpretation rule

- Mathematical theorem + explicit assumptions -> may be listed as `VERIFIED`.
- Empirical result -> report effect size, uncertainty, held-out design and limitations.
- A null/inconclusive result remains in the repository.
- No observational temporal coefficient is labeled causal without a separate identification argument.

## Current release status

Python scientific core: validated by local tests and self-contained reproduction.

Rust source: rewritten but **not compiled in the construction environment because `cargo/rustc` were unavailable**. Therefore this artifact is `2.0.0-research-candidate`, not final `2.0.0`.
