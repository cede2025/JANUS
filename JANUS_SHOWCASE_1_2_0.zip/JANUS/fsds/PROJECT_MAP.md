# FSDS v2 Repository Map

```text
FSDS_v2/
├── FSDS_CLAIM_REGISTRY_V2.md      # epistemic freeze: VERIFIED / SUPPORTED / REJECTED
├── PROJECT_MAP.md
├── README.md
├── VERSION
├── pyproject.toml
├── requirements.lock
├── environment.yml
├── Cargo.lock                     # mirrored Rust dependency lock
├── manifest.sha256
├── reproduce.sh                   # single-command reproduction gate
├── run_all_tests.sh
├── fsds_v2/
│   ├── linear_sde.py              # dX = A X dt + G dW
│   ├── stability.py               # spectral abscissa / Hurwitz status
│   ├── graph.py                   # parameter graph j -> i iff A[i,j]
│   ├── metrics.py
│   ├── simulation.py
│   ├── matrix_functions/
│   │   ├── expm.py                # real-Schur + stable expm
│   │   ├── covariance.py          # exact Q_Delta via Van Loan block exponential
│   │   └── logm.py                # checked diagnostic log; never silent take(real)
│   ├── estimators/
│   │   ├── var.py                 # baseline ridge VAR
│   │   ├── ct_nls.py              # exact irregular-dt CT-NLS + Frechet gradient
│   │   └── ct_likelihood.py       # Gaussian CT likelihood + NaN-aware Kalman filter
│   ├── critical_transition/
│   │   └── indicators.py          # descriptive indicators + change-point baselines
│   └── cascade/
│       ├── fsds_cascade.py        # local FSDS overload model
│       └── motter_lai_reference.py
├── benchmarks_v2/
│   ├── parameter_recovery.py
│   ├── stability_detection.py
│   ├── irregular_sampling.py
│   ├── false_positive_analysis.py
│   ├── missing_data.py
│   ├── cascade_prediction.py
│   └── run_all.py
├── real_data/
│   ├── EMA_PREREGISTRATION_V2.md
│   ├── validate_ema_lopo.py
│   └── source/                    # supplied Rowland EMA + KONECT files used/provided for reproduction
├── rust_ctvar_v2/
│   ├── Cargo.toml
│   ├── Cargo.lock
│   └── src/lib.rs                 # explicit orientation, irregular dt, Padé expm, CT-NLS objective/tests
├── tests/                         # 14 Python scientific/implementation tests
├── docs/
│   ├── MATHEMATICAL_SPEC.md
│   ├── FSDS_V2_TECHNICAL_REPORT.md
│   ├── RELEASE_GATE.md
│   ├── REPRODUCIBILITY.md
│   ├── MIGRATION_FROM_V1.md
│   └── FSDS_V1_INDEPENDENT_AUDIT.md
├── deprecated/legacy_benchmarks/ # provenance only; excluded from v2 evidence
├── scripts/
│   ├── build_technical_report.py
│   ├── generate_manifest.py
│   └── verify_manifest.py
└── results/
    ├── benchmarks_v2.json
    ├── ema_lopo_v2.json
    └── reproduction_status.json
```
