# EMA validation preregistration — FSDS v2

This protocol is frozen **before** the v2 LOPO results are inspected.

- Dataset: `source/ema_rowland_2020.csv` supplied with the audit materials.
- Subjects: first 50 unique `subjno` values in ascending order. No subject is removed based on outcome.
- Variables: `emo1_m` ... `emo6_m`.
- Ordinal time: `10*dayno + beep`. This encodes observation order and skipped beeps, **not clock time**.
- Transition inclusion: both adjacent observations must have all six variables finite and positive `Delta t`.
- Validation: leave-one-person-out. For each held-out person, preprocessing parameters and both models are fit only from the other 49 persons.
- Preprocessing: feature-wise mean and standard deviation from training persons only; no outcome-dependent filtering.
- VAR baseline: ridge lambda = 1.0.
- CT-NLS: exact individual-Delta objective, ridge lambda = 1.0, L-BFGS-B, maxiter = 80.
- No hyperparameter tuning after results are seen.
- Metrics per person: RMSE, MAE, correlation, CT max-real-eigenvalue.
- Primary comparison: paired `RMSE_CT - RMSE_VAR` across held-out persons, with nonparametric bootstrap 95% CI over persons.
- Interpretation: an interval crossing zero is inconclusive. A negative difference supports CT-NLS predictive improvement for this protocol only; a positive difference supports VAR for this protocol only.
- This analysis does not identify causal effects and does not validate a crisis detector.
