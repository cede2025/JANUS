# FSDS 2.0.0-RC1 Release Notes

## Scientific changes

- Replaced informal ODE-plus-noise notation by an explicit linear Itô SDE.
- Added exact transition covariance and separated stability, stationarity and prediction.
- Replaced legacy mean-log CT estimator by exact individual-interval CT-NLS.
- Added a Gaussian continuous-discrete state-space likelihood with missing-data support.
- Added a conservative matrix-function safety layer; no silent removal of complex log components.
- Made row/column orientation explicit.
- Replaced inherited benchmark evidence with ground-truth recovery experiments.
- Renamed CSD functionality to Critical Transition Indicators and added null false-alarm tests.
- Renamed the local cascade model and isolated a separate classical Motter-Lai reference model.
- Added N=50 frozen EMA leave-one-person-out evaluation.
- Added claim registry, reproducibility manifest and one-command gate.

## Negative / inconclusive results retained

- Near-zero stability remains hard to classify reliably in the quick benchmark.
- Critical-transition indicators show material false alarms on noncritical processes.
- EMA LOPO does not establish predictive superiority of CT-NLS over VAR; the bootstrap CI for the paired RMSE difference crosses zero.

## Release blocker

The Python core passes all local gates. Rust v2 source was rewritten, but `cargo/rustc` were not available in the construction environment. The release therefore remains **RC1** until the locked Rust crate compiles and its required tests pass.
