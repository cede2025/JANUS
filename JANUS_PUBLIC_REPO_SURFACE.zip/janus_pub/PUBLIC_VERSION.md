# Public version

**Public Research Edition**

This label applies to the public architecture and documentation surface only.  
It is not an internal product version and should not be confused with private runtime releases.

Current public evaluation candidate referenced in research status: `1.2.0-EMPIRICAL_BOUNDARY_CANDIDATE` (already public in the evaluation artifact).
