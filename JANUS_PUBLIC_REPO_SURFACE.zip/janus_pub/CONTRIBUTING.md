# Contributing

Thank you for your interest in the public JANUS research surface.

## What contributions are welcome

- Improvements to public documentation clarity.
- Corrections of factual errors in public materials.
- Additional public educational examples that remain within the publication boundary.
- Discussion of research questions and limitations.
- Suggestions for public diagrams or terminology refinements.

## What is out of scope for public contributions

- Requests to publish withheld implementation or formal specification.
- Submission of code that implements the proprietary JANUS mechanism.
- Changes that would upgrade evidence statuses beyond the authoritative claim registries.
- Marketing claims or language that exceeds the documented evidence.

## Process

1. Open an issue describing the proposed change.
2. Keep changes limited to GREEN public-surface material.
3. Do not submit secrets, private datasets, or materials under restrictive licenses without explicit clearance.

By contributing you agree that your contribution may be released under the license chosen for this public repository (see LICENSE).
