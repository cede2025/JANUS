# Public Roadmap

This roadmap covers only the **public research and documentation surface**. It does not disclose private commercialization or patent strategy.

## Public research

- Clarify and expand public research questions.
- Maintain explicit negative-result documentation.
- Improve public terminology consistency.

## Validation (public surface)

- Keep public claim register synchronized with authoritative evaluation artifact statuses.
- Document additional independent public data sources only when license and IP boundary permit.

## Engineering (public educational layer)

- Expand educational examples (epistemic state, action proposal, simulation-only flows).
- Keep examples free of proprietary mechanism implementation.

## Documentation

- Refine architecture and principles documents.
- Improve FAQ based on external questions.
- Maintain clear separation between public surface and withheld materials.

## Tooling

- Public diagram source (SVG) maintenance.
- Link and formatting checks for documentation.

## External collaboration

- Clear pathways for research discussion within the public boundary.
- Source-access requests handled under separate written agreement.

## Future open components

Any future opening of additional layers will be deliberate, versioned, and consistent with the existing public narrative.
