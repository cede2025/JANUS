# Code of Conduct

## Our standards

We expect participants in public discussion around this repository to:

- focus on technical and scientific substance;
- respect the published evidence boundaries;
- avoid personal attacks;
- avoid pressure to disclose withheld materials;
- treat negative results and limitations as legitimate scientific content.

## Enforcement

Unacceptable behavior may result in moderated comments or restricted participation in public channels associated with this repository.

## Reporting

Report concerns to the maintainers through private channels.
