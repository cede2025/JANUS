# Diagrams (Principle-Level)

All public diagrams are **conceptual**. They frame a problem; they do not show an implementation path.

Preferred public graphic:

`Observation → Inference → Evidence → Governance → Action`

Additional principle diagrams, if used, stay at the same level of abstraction.

## Design rules

- Readable labels
- Works in light and dark backgrounds
- No proprietary module names beyond public vocabulary
- No equations or parameters
- Source form kept for reproducibility
