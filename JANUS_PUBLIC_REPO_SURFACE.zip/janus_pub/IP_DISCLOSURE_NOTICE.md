# IP Disclosure Notice

This public repository presents a **selected research and engineering view** of the JANUS project.

Certain implementation details, formal mathematical specifications, parameterization, algorithmic constructions, and internal mechanisms are **intentionally not included**.

The absence of those materials is deliberate. It does not imply that they do not exist; it reflects a conscious public boundary around proprietary and potentially patent-sensitive subject matter.

This repository is **not** a patent application and does not establish legal patent scope.

No statement in this repository should be interpreted as a claim of patent protection, patent-pending status, or exclusive rights unless and until such status is independently and explicitly confirmed through formal channels.

For qualified technical evaluation of materials beyond this public boundary, contact the project maintainers under a separate written agreement.
