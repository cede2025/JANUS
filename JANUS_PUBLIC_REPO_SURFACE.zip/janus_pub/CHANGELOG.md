# Changelog

## Public Research Edition (initial public architecture surface)

- Establishment of the public Pre-Patent Safe Edition surface.
- Publication of high-level architecture, principles, epistemic vocabulary, and governance concepts.
- Publication of research status and public claim register aligned with existing evaluation artifact statuses.
- Explicit IP disclosure notice and publication boundary.
- Principle-level diagrams (architecture overview, capability separation, epistemic lifecycle, proposal-to-execution, controlled adaptation).
- Educational examples that do not implement the proprietary mechanism.
- Retention of negative-result and limitation language.

No claim statuses from the authoritative evaluation artifact have been upgraded.
