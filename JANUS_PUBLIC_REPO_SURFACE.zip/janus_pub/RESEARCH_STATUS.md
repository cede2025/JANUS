# Research Status

**Public edition label:** Public Research Edition  
**Internal reference (already public):** 1.2.0-EMPIRICAL_BOUNDARY_CANDIDATE  

## Evidence vocabulary (authoritative)

| Status | Meaning |
|--------|---------|
| VALIDATED | Supported by reproducible evidence within the documented scope |
| PARTIAL | Supported only under limited conditions or a subset of the protocol |
| TESTED | Exercised by the documented test suite / harness |
| SUPPORTED | Consistent with available evidence but not fully closed |
| EXPERIMENTAL | Currently under evaluation |
| UNVERIFIED | Conceptual or insufficiently tested |
| FALSIFIED | Specific hypothesis failed its validation criterion |
| DEFERRED | Explicitly postponed |

Statuses used in this public repository are taken from the existing evaluation artifact claim registries. **No statuses have been upgraded for public presentation.**

## Boundary statements (authoritative)

- The V1.1 epistemic execution-integrity boundary is closed for the documented **local/single-node reference runtime**.
- The V1.2 empirical boundary is intentionally **not** claimed closed. Additional independent qualifying sources are required by the frozen protocol.
- Evidence in the public evaluation artifact is stabilized for a local/single-node reference runtime. Optional cloud profiles (PostgreSQL/Redis/Celery/Kubernetes) require separate infrastructure validation.
- The system is **not** certified for medical, aviation, or other safety-critical use.

## What has been demonstrated (process level)

Within the local reference scope and the published evidence:

- immutable, canonical decision contracts;
- proposal-to-assessment binding to an exact epistemic snapshot;
- commit-time revalidation of epistemic state and authorization;
- fail-closed audit/evidence persistence;
- single-consume execution semantics within the local execution authority;
- explicit fallback behavior;
- deterministic evidence lineage;
- formal continuous-time state/dynamics primitives (as tested);
- reproducible empirical validation protocols;
- bounded robustness experiments for the documented enforcement path.

Evidence for these statements resides in the evaluation artifact (`evidence/`, claim registries, validation reports). This public repository does not re-state numerical results beyond what is already public.

## What remains open

- Full empirical boundary closure across multiple independent sources.
- Infrastructure validation of optional cloud profiles.
- Formal controller / reachability results (explicitly future work).
- Any claim of physical safety, causal identification, universal OOD detection, or regulatory certification.
