# Public Claim Register

Only architectural and process-level claims that remain within the public publication boundary are listed.

| ID | Claim | Status | Evidence scope | Public-safe |
|----|-------|--------|----------------|-------------|
| JANUS-C-001 | JANUS explicitly separates capability from execution authority | ARCHITECTURAL | Design principle + evaluation artifact documentation | Yes |
| JANUS-C-002 | JANUS represents epistemic state separately from raw model output | ARCHITECTURAL | Design principle + evaluation artifact | Yes |
| JANUS-C-003 | An ActionProposal does not by itself constitute authorization to execute | ARCHITECTURAL | Design principle | Yes |
| JANUS-C-004 | Learning / evidence accumulation does not automatically grant higher operational authority | ARCHITECTURAL | Design principle | Yes |
| JANUS-C-005 | Fail-closed behavior is required on the documented local audit/persistence path | TESTED (local reference) | Evaluation artifact SECURITY + tests | Yes (scope-limited) |
| JANUS-C-006 | Authorization changes can invalidate dependent outstanding permits within the local execution-authority clock domain | TESTED (local reference) | Evaluation artifact | Yes (scope-limited) |
| JANUS-C-007 | The V1.2 empirical boundary is not claimed closed | PROCESS | RELEASE_STATUS / evaluation artifact | Yes |
| JANUS-C-008 | Negative and inconclusive results are retained rather than converted into positive claims | PROCESS | Evaluation artifact policy | Yes |

No claim in this register asserts patent status, physical safety certification, AGI, consciousness, or universal correctness.
