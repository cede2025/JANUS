# Publication Boundary

## Purpose

This document defines what the public JANUS repository is intended to contain and what it intentionally excludes.

## Public surface (GREEN)

The public repository may contain:

- high-level architecture and conceptual lifecycle;
- design philosophy and architectural principles;
- problem statement and research questions;
- conceptual epistemic and governance vocabulary;
- selected public experimental results whose disclosure does not reveal the inventive mechanism;
- process-level reproducibility philosophy;
- negative results and limitations;
- public claim register limited to architectural / process-level statements with explicit evidence status;
- educational examples that do not implement the proprietary mechanism;
- principle-level diagrams;
- public documentation, roadmap, and contribution guidelines.

## Public boundary

Implementation-specific mechanisms, proprietary parameters, internal execution protocols, and reconstruction details are intentionally withheld from the public layer.

Credentials, secrets, and private infrastructure information are also excluded.

## Classification rule

Material is published only when it can be clearly classified as safe for a pre-patent public boundary.

If classification is ambiguous, the material is withheld or marked for explicit owner / counsel review.

## Relationship to source access

Source code, the detailed mechanism specification, and related technical materials remain available for qualified evaluation under separate written agreement. See `SECURITY.md`.
