# JANUS

**An Epistemically Governed, Mathematically Evolving Architecture**

A system architecture for separating cognition, epistemic state, trust, authorization and execution.

> **Capability ≠ Authority ≠ Authorization ≠ Execution**

JANUS investigates what happens when a system is allowed to reason without being allowed to act by default.

A longer public essay — origin of the question, without treating origin as proof — is in [docs/from-observation-to-action.md](docs/from-observation-to-action.md).

---

## Public definition

JANUS is an epistemically governed execution architecture for AI systems. It introduces explicit separation between cognition, epistemic state, trust, authorization and execution, allowing an AI system to reason about uncertainty without automatically converting reasoning into action.

---

## Why this exists

A common agent pattern is:

```
Observation → Model inference → Tool / action → Outcome
```

Inference quality does not automatically imply authorization.

A system can be:

- capable but uncertain;
- confident but wrong;
- informed but unauthorized;
- authorized but operating under stale state;
- technically able to execute but not epistemically justified.

JANUS studies the missing governance layer between possibility and permitted action.

---

## Conceptual architecture

```
Observation
→ Cognition
→ Epistemic State
→ Maturity / Trust
→ Authorization
→ Execution / Simulation
→ Evidence
→ Belief Update
```

See [docs/architecture.md](docs/architecture.md) and the principle-level diagrams in `diagrams/`.

---

## Core principles (summary)

1. Capability ≠ Authority ≠ Authorization ≠ Execution  
2. Learning ≠ Self-Promotion  
3. Uncertainty ≠ Semantic Zero  
4. Maturity ≠ Trust  
5. Observation ≠ Knowledge  
6. Hypothesis ≠ Belief  
7. Proposal ≠ Action  
8. Execution must be governed  
9. Negative evidence matters  
10. Adaptation must remain governed  

Full explanations: [docs/principles.md](docs/principles.md)

---

## What this repository is

This is the **public research and architecture surface** (Pre-Patent Safe Edition).

It is an **evaluation artifact / research-grade reference presentation**.  
It does **not** contain the full implementation or the complete formal specification.

Source code and detailed mechanism materials remain available for qualified technical evaluation under separate written agreement.

See:

- [IP_DISCLOSURE_NOTICE.md](IP_DISCLOSURE_NOTICE.md)
- [PUBLICATION_BOUNDARY.md](PUBLICATION_BOUNDARY.md)
- [SECURITY.md](SECURITY.md)

---

## Research status

Authoritative statuses and boundary statements are recorded in:

- [RESEARCH_STATUS.md](RESEARCH_STATUS.md)
- [PUBLIC_CLAIM_REGISTER.md](PUBLIC_CLAIM_REGISTER.md)

**No claim statuses have been upgraded for public presentation.**  
Negative and inconclusive results are retained.

---

## What JANUS is not

- simply another LLM  
- just a prompt framework  
- merely an agent loop  
- a generic workflow engine  
- synonymous with reinforcement learning  
- a replacement for model training  
- a guarantee of correctness or safe behavior  
- a claim of consciousness or AGI  

---

## How claims are written

- Scope first: conditions, data, test.
- Mechanism is not result. Definition or implementation is not empirical confirmation.
- A passing test confirms that test, not a general law.
- Hypotheses carry explicit labels (VALIDATED, PARTIAL, OPEN, FALSIFIED, …).
- Mathematics, implementation, experiment, and scientific interpretation are separate levels.
- Absolute verbs are avoided unless the evidence actually supports them.
- Project history explains a question. It does not prove a formalism.
- Attractive ideas may be stated as **research directions**, not as results.

See [docs/from-observation-to-action.md](docs/from-observation-to-action.md) for the careful public position and the essay.

## Documentation map

| Document | Content |
|----------|---------|
| [docs/from-observation-to-action.md](docs/from-observation-to-action.md) | Careful public position + origin essay |
| [docs/overview.md](docs/overview.md) | Orientation |
| [docs/architecture.md](docs/architecture.md) | Public architecture view |
| [docs/principles.md](docs/principles.md) | Ten architectural principles |
| [docs/epistemic-model.md](docs/epistemic-model.md) | Conceptual epistemic states |
| [docs/governance.md](docs/governance.md) | Proposal → authorization |
| [docs/execution.md](docs/execution.md) | Execution / simulation posture |
| [docs/research.md](docs/research.md) | Public research questions |
| [docs/negative-results.md](docs/negative-results.md) | Intellectual honesty |
| [docs/applications.md](docs/applications.md) | Potential domains |
| [docs/terminology.md](docs/terminology.md) | Glossary |
| [docs/limitations.md](docs/limitations.md) | Explicit limits |
| [docs/faq.md](docs/faq.md) | FAQ |
| [docs/grow-integration.md](docs/grow-integration.md) | Public integration view |

---

## Citation

See [CITATION.cff](CITATION.cff).

---

## License

See LICENSE. Public visibility and licensing are distinct concepts; the license file is the authoritative statement of reuse terms for the public materials.

---

*This public surface is designed for technical credibility, scientific honesty, and a deliberate pre-patent publication boundary.*
