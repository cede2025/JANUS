# Governance (Public Conceptual View)

## Core idea

Cognition may produce an **ActionProposal**.  
A governance layer evaluates whether that proposal may become executable.

```
ActionProposal
→ epistemic evaluation
→ policy evaluation
→ authorization decision
→ execution or simulation
```

## Separation from capability

Model capability (the ability to generate fluent, high-scoring, or well-calibrated outputs) does not itself constitute authorization.

Epistemic sufficiency does not itself grant permission.

## Authorization (conceptual)

Authorization is treated as a distinct decision, independent of model capability and of epistemic sufficiency.

Implementation-specific mechanisms, proprietary parameters, internal execution protocols, and reconstruction details are intentionally withheld from the public layer.

## Maturity and trust

- **Maturity** — demonstrated reliability under defined conditions (evidence-driven).
- **Trust** — operational confidence within a governance context.

They are not interchangeable.
