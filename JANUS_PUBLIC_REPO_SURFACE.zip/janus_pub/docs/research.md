# Research Questions (Public)

The following questions guide public discussion of the architecture.  
They do not disclose the full experimental apparatus.

1. Can an architecture distinguish a change in observed behavior from a change in underlying regime?
2. Can epistemic contradictions trigger appropriate revision without granting uncontrolled authority?
3. Can evidence accumulation improve model selection without automatically increasing execution privilege?
4. Can governance remain stable while the underlying cognitive model changes?
5. Can failure remain observable instead of being silently absorbed into context or parameters?
6. Can controlled adaptation improve performance without collapsing the distinction between learning and authorization?

## Evidence discipline

Every concrete result referenced from the public surface carries an explicit status (VALIDATED, PARTIAL, TESTED, EXPERIMENTAL, UNVERIFIED, FALSIFIED, …) taken from the authoritative evaluation artifact.  
Statuses are not upgraded for presentation.
