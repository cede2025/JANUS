# Architectural Principles

Each principle is stated in plain technical language. None of these statements discloses implementation parameters or the full formal mechanism.

## 1. Capability ≠ Authority ≠ Authorization ≠ Execution

A system may be able to generate a high-quality plan without possessing the authority to carry it out. Authority is not the same as a concrete authorization for a specific action. Authorization is not the same as the act of execution.

## 2. Learning ≠ Self-Promotion

Accumulation of evidence or improvement in predictive performance does not automatically expand operational authority. Learning and authorization remain distinct.

## 3. Uncertainty ≠ Semantic Zero

Ordinary uncertainty (“we have a distribution over possibilities”) is not identical to a state in which a proposed interpretation is not sufficiently valid to support normal downstream reasoning. The architecture treats these as different conditions.

## 4. Maturity ≠ Trust

Maturity concerns demonstrated reliability under defined conditions. Trust concerns operational confidence granted within a governance context. One does not silently become the other.

## 5. Observation ≠ Knowledge

Raw input is not automatically a verified representation of state. Observation must be distinguished from reconstructed or validated knowledge.

## 6. Hypothesis ≠ Belief

A generated hypothesis is a candidate. It does not silently become a trusted representation of reality.

## 7. Proposal ≠ Action

An AI system can emit an ActionProposal without being permitted to execute it.

## 8. Execution must be governed

External effects require explicit authorization that is independent of the generative model’s confidence or fluency.

## 9. Negative evidence matters

Failed predictions, contradictions, and falsifications remain part of the epistemic history. They are not to be silently discarded.

## 10. Adaptation must remain governed

A system should not silently rewrite its own authority boundaries while adapting its models or policies.
