# Overview

## What JANUS is

JANUS is an **epistemically governed execution architecture** for AI systems.

It introduces an explicit separation between:

- cognition (reasoning, prediction, hypothesis generation);
- epistemic state (what is known, unknown, contradicted, or insufficient);
- trust and maturity (evidence-driven assessments);
- authorization (whether an action may be executed);
- execution (actual effect on the external world).

A model may infer, predict, hypothesize, propose, or plan.  
None of those properties alone implies permission to affect the external world.

## Public definition

> JANUS is an epistemically governed execution architecture for AI systems. It introduces explicit separation between cognition, epistemic state, trust, authorization and execution, allowing an AI system to reason about uncertainty without automatically converting reasoning into action.

## What this repository is

This repository is the **public research and architecture surface** of the project (Pre-Patent Safe Edition).

It is an evaluation-oriented, research-grade reference presentation. It does **not** contain the full implementation or the complete formal specification.

## Conceptual pipeline

```
Observation
→ Cognition
→ Epistemic State
→ Maturity / Trust
→ Authorization
→ Execution / Simulation
→ Evidence
→ Belief Update
```

An extended research lifecycle also includes canonicalization, state reconstruction, dynamic inference, epistemic evaluation, retrospection, and controlled adaptation.

## Core separation

**Capability ≠ Authority ≠ Authorization ≠ Execution**

This separation is the central architectural commitment of the public surface.
