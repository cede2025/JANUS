# Negative Results and Intellectual Honesty

JANUS research records failure.

Some hypotheses investigated during development did not survive experimental validation.

Performance improvement is not assumed merely because the architecture permits a mechanism.

Several proposed adaptations failed to produce measurable improvement under controlled experiments.

Negative and inconclusive results are retained in the evaluation artifact rather than converted into positive claims.

This section exists to make that policy visible on the public surface.

Where specific falsified or partial claims are already public in the evaluation artifact claim registries, they remain authoritative.
