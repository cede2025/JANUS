# Epistemic Model (Public Conceptual View)

## Purpose

JANUS treats epistemic status as a first-class concern.  
Raw model output is not treated as equivalent to validated knowledge.

## Conceptual states

| State | Meaning (public) |
|-------|------------------|
| Observed | Directly available information |
| Reconstructed | Normalized or internal representation of observations |
| Inferred | Derived from available evidence under stated assumptions |
| Hypothesized | Candidate explanation not yet validated |
| Validated | Supported under defined validation conditions |
| Uncertain | Known to be incomplete or noisy |
| Contradicted | Evidence conflicts with the representation |
| Unavailable / Open | Insufficient basis for stronger claims |

These labels are conceptual.

## Semantic Zero (conceptual)

JANUS distinguishes ordinary uncertainty from situations in which a proposed interpretation is not sufficiently semantically valid to support ordinary downstream reasoning.

Implementation-specific mechanisms, proprietary parameters, internal execution protocols, and reconstruction details are intentionally withheld from the public layer.

## Hypothesis vs belief

A hypothesis is a candidate structure.  
A belief is a representation that has passed defined epistemic evaluation.  
The architecture keeps the two distinct.
