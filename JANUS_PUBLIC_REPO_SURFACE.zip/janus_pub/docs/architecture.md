# Architecture (Public View)

## High-level modules

The public architecture distinguishes the following conceptual layers:

| Layer | Responsibility (public) |
|-------|-------------------------|
| Observation | Intake of external signals and inputs |
| Cognition | Reasoning, hypothesis generation, planning, proposal formation |
| Epistemic State | Representation of knowledge status (observed, inferred, hypothesized, validated, contradicted, open, …) |
| Dynamic Inference | Reasoning about evolving state and temporal structure (conceptual) |
| Epistemic Evaluation | Assessment of sufficiency, contradiction, and validity of interpretations |
| Maturity / Learning | Evidence-driven assessment of demonstrated reliability |
| Trust | Operational confidence within a governance context |
| Authorization Gate | Decision whether a proposal may become executable |
| Execution / Simulation | Controlled effect or simulated effect |
| Evidence | Record of outcomes, failures, and lineage |
| Retrospection | Review of outcomes against prior state and predictions |
| Controlled Adaptation | Governed update of models or policies without silent self-promotion |

## Three paths

**Cognitive path**  
Observation → Cognition → Hypothesis → Prediction

**Governance path**  
Epistemic State → Maturity → Trust → Authorization → Execution

**Feedback path**  
Outcome → Evidence → Retrospection → Belief Update → (possible Controlled Adaptation)

## Important public boundary

This document describes responsibilities and relationships at a conceptual level.  
It does not publish internal graph topology, exact interfaces of the proprietary runtime, or the complete formal specification.
