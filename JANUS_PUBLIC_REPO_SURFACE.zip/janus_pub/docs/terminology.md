# Terminology (Public Glossary)

| Term | Public meaning |
|------|----------------|
| JANUS | Epistemically governed execution architecture; public surface is an evaluation / research presentation |
| Cognition | Reasoning, hypothesis generation, planning, proposal formation |
| Epistemic State | Representation of knowledge status (observed, inferred, hypothesized, validated, contradicted, open, …) |
| Hypothesis | Candidate explanation not yet validated |
| Belief | Representation that has passed defined epistemic evaluation |
| Evidence | Recorded outcomes, failures, lineage, and supporting material |
| Maturity | Evidence-driven assessment of demonstrated reliability under defined conditions |
| Trust | Operational confidence within a governance context |
| Authorization | Decision that a specific proposal may become executable |
| Execution | Actual effect on the external world (or controlled simulation) |
| ActionProposal | Candidate action emitted by cognition; not itself authorization |
| Semantic Zero | Conceptual label for situations in which a proposed interpretation is not sufficiently valid for ordinary downstream reasoning |
| Simulation | Evaluation without external effect (or within a sandbox) |
| Validation | Assessment against defined conditions |
| Retrospection | Review of outcomes against prior predictions and state |
| Controlled Adaptation | Governed update that does not silently expand authority |

Internal or proprietary terms beyond this glossary are intentionally omitted.
