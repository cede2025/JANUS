# Grow Integration (Public View)

## Conceptual relationship

The public JANUS repository is the durable, reviewable surface for architecture, principles, research status, and public evidence boundary.

Connected research and engineering workflows (including environments used for private development and evaluation) remain outside this public surface.

## What the public repository provides

- Canonical public definitions and principles.
- Claim and research status aligned with the evaluation artifact.
- Publication boundary and IP disclosure notice.
- Educational examples and principle-level diagrams.

## What remains internal

- Full implementation and formal specification.
- Private orchestration, credentials, and non-public endpoints.
- Detailed experimental machinery not cleared for public release.

## Interaction

Researchers and collaborators can:

- read and discuss the public surface;
- open issues within the contribution guidelines;
- request access to materials beyond the public boundary under separate written agreement.

No private credentials or internal endpoints are published here.
