# Execution (Public Conceptual View)

## Execution modes (conceptual)

Progressively stronger operational states may include:

- Observe
- Analyze
- Simulate
- Experimental
- Validated
- Authorized
- Execute

These names are illustrative of a graduated posture. The complete internal transition graph is not published.

## Simulation vs execution

The architecture distinguishes:

- simulation (no external effect, or effect confined to a sandbox);
- authorized execution (external effect under explicit authorization).

A proposal may be evaluated and still remain non-executable.

## Fail-closed posture (documented local scope)

On the documented local reference path, certain failures (for example audit/persistence failure) are required to surface rather than be silently ignored.  
This is a scoped statement about the local reference, not a universal safety certificate.
