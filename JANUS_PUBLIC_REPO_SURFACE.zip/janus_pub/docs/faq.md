# FAQ

**What is JANUS?**  
An epistemically governed execution architecture that separates cognition, epistemic state, trust, authorization, and execution.

**Is JANUS an LLM?**  
No. It is an architecture for governing execution around (among other things) model-based cognition.

**Is JANUS an agent framework?**  
It addresses a governance layer that common agent loops often leave implicit. It is not merely another agent loop.

**What problem does JANUS address?**  
The fact that inference quality, confidence, or fluency does not automatically constitute authorization to act on the external world.

**How is JANUS different from a typical AI agent?**  
Typical patterns often move from model output toward tool use with limited explicit separation of epistemic status and authorization. JANUS treats that separation as architectural.

**Does JANUS guarantee safe behavior?**  
No. It is an architecture for explicit epistemic and execution governance. Safety depends on policy, implementation, deployment context, verification, monitoring, and human governance.

**Does JANUS replace human governance?**  
No.

**Does JANUS train the underlying model?**  
The public architecture is not a training method. Learning and authorization remain distinct.

**What does “epistemically governed” mean?**  
That decisions about execution take explicit account of epistemic status (what is known, unknown, contradicted, or insufficient) rather than treating model output as automatically actionable.

**What is the difference between maturity and trust?**  
Maturity is about demonstrated reliability under defined conditions. Trust is operational confidence within a governance context.

**What is an ActionProposal?**  
A candidate action produced by cognition. It is not itself authorization to execute.

**What is Semantic Zero?**  
A conceptual distinction for cases in which a proposed interpretation is not sufficiently valid to support ordinary downstream reasoning. Implementation-specific mechanisms are withheld from the public layer.

**Is the full JANUS implementation open source?**  
No. This repository is a public research and architecture surface. Source and detailed specification are available for qualified evaluation under separate written agreement.
