# From Observation to Action

This page has two layers on purpose.

1. A **careful public position** — what can be stated without inflating evidence and without disclosing reconstructable mechanism.
2. An **essay** — why the problem is interesting, written so it can be read in public.

The essay is not evidence. Origin is not proof.

---

## 1. Careful public position

### What JANUS is, publicly

JANUS is a research and engineering programme for systems that observe changing processes, form representations of those processes, and must decide whether any proposed action is justified.

Publicly, JANUS is defined as an **epistemically governed execution architecture**: it keeps cognition, epistemic status, trust, authorization, and execution as distinct concerns, so that reasoning is not treated as permission to act.

This repository is an **evaluation artifact / research-grade public surface**.  
It is not a source-disclosure release and does not contain the complete implementation or the complete formal specification.

### Scope rule

Every technical statement below is scoped.

| Layer | What a result at this layer can support | What it cannot support by itself |
|-------|------------------------------------------|----------------------------------|
| Concept / architecture | That a distinction is defined and used as a design rule | That the distinction is empirically effective in deployment |
| Mathematics | That a representation is well-posed under stated assumptions | That the representation matches a real process |
| Implementation | That a behaviour was coded and can be tested | That the behaviour is generally useful |
| Experiment / test | That a specified test passed or failed under specified conditions | That JANUS “has” the property in general |
| Interpretation | A cautious reading of a result | A scientific law or a safety certificate |

A passing test confirms behaviour **in that test**, under those conditions, on those data, against that criterion. It does not automatically become a general property of JANUS.

### What is claimed here (architectural / process)

These statements are architectural commitments or process facts already established on the public evaluation surface. They are not upgraded.

- JANUS treats **capability, authority, authorization, and execution** as distinct.
- An **ActionProposal** is not authorization.
- Learning or evidence accumulation does not automatically expand operational authority.
- Epistemic status is represented separately from raw model output.
- On the documented **local / single-node reference runtime**, selected execution-integrity and fail-closed behaviours have been **tested** within that scope.
- The empirical boundary of the current public evaluation candidate is **not** claimed closed.
- Negative and inconclusive results are retained rather than rewritten as successes.

Statuses used on the public surface remain those of the authoritative claim register: VALIDATED, PARTIAL, TESTED, SUPPORTED, EXPERIMENTAL, UNVERIFIED, FALSIFIED, DEFERRED, OPEN.  
No status is raised for presentation.

### What is not claimed

JANUS does not, on the basis of this public surface:

- guarantee correct decisions;
- guarantee safe behaviour;
- certify medical, aviation, or other safety-critical use;
- claim causal identification from observational correlation;
- claim that a model “understands” a mechanism because it predicts;
- claim that mathematical elegance implies epistemic warrant;
- claim that a single experiment establishes a general law;
- claim consciousness, general intelligence, or unbounded autonomy.

Safety, if it exists in a deployment, would depend on policy, implementation, verification, monitoring, threat model, and human governance — not on architecture language alone.

### Public boundary

This page describes a problem, a layering of concerns, and a research direction.

Implementation-specific mechanisms, proprietary parameters, internal execution protocols, and reconstruction details are intentionally withheld from the public layer.

Interesting questions may be stated attractively.  
They remain **research directions** until they carry an explicit evidence status and a specified test.

### How to read results

If a result can be reproduced from public materials against a stated criterion, it is a stronger public claim than an ambition.

If a result lives only in private implementation, it is not treated here as a public demonstration.

If a hypothesis is attractive, it is labelled as a hypothesis.

---

## 2. Essay — from a moving observation to a governed action

JANUS did not begin as a desire to build a large architecture.

It began with a smaller question:

**How do you describe a system whose state is not a fixed thing, but something that keeps happening?**

The question first appeared around repeated measurement of lived experience over time.  
A single value can say where a system is now.  
A trajectory starts to say how it got there.

That difference mattered.

If you observe a system at many points in time, are you looking at many independent measurements?  
Or at fragments of one continuing history?

Attention moved from isolated values to relations between states: rate of change, temporal dependence, coupling, context, stability, and transitions.

The question was no longer only how to describe a system.  
It became how to try to understand a system from the way it evolves.

### When a point becomes a trajectory

At first the shift looked small.

Instead of asking *what is the level of this variable*,  
the work asked *how this state is changing* —  
and then *what must be true of the dynamics before any claim about that change is reliable*.

Several traditions offered part of an answer: network psychometrics, longitudinal analysis, autoregressive models, continuous-time models, stochastic processes, dynamical systems.

Each contributed something.  
None closed the whole problem.

That gap became the interesting part.

The project moved from measurements to states, from states to dynamics, and then to a harder question:

**What can actually be known from an observed trajectory?**

### A person was the beginning, not the boundary

It became clear that the mathematical difficulty was not confined to one field.

A person is a dynamical system.  
So is an industrial process.  
A network.  
A biological process.  
A market.  
An infrastructure that can overload and cascade.  
And later, a computational system that can itself observe, model, interpret, and act.

Across domains the same difficulty returns:

we observe only part of a system, while the system has a history and is still changing.

The object of interest was therefore not one discipline and not one data type.  
It was **the dynamics of a partially observed system**.

### Early models were not the last word

Early versions were sometimes more ambitious in interpretation than the evidence allowed.

Predictive dependence could be read too strongly.  
Some indicators of changing dynamics were given a wider meaning than could be justified.  
Some numerical procedures needed tighter constraints.  
In a few places the language of the project ran ahead of its evidence.

That became a turning point.

Instead of protecting the first assumptions, the work began to test them.  
Counterexamples were built.  
Conditions were sought under which an expected effect disappears.  
Stability of results was checked.  
What had been observed was separated from what had only been inferred.

Some hypotheses survived.  
Some were weakened.  
Some were rejected.

The aim was no longer only to build a more complicated model.  
It became also to build a system that can recognise the limits of its own conclusions.

### A model is not the world

One of the central lessons is a set of distinctions:

what a system observes,  
what it estimates,  
what it predicts,  
and what it interprets.

A model may recover structure.  
That does not mean it knows a cause.

A model may predict.  
That does not mean it understands a mechanism.

A model may be mathematically consistent.  
That does not mean its interpretation matches reality.

This is not treated as a defect.  
It is one of the foundations of the work.

The more complex the system under description, the more important it becomes to ask not only *what do we know*, but *how do we know it*, and *where does the warrant for this claim end*.

### From dynamics to epistemology

State estimation is not enough.

If a system can observe, model, and predict, it also has to distinguish epistemic statuses:

observation → inference → hypothesis → evaluated belief

These are not the same thing.  
None of them, by itself, is permission to act.

If a system can say *the most probable state looks like this*, a further question appears:

**Is that a sufficient basis to do something?**

Not necessarily.

And if not, a harder question follows:

**What should decide whether action is justified?**

At that point the work moved from modelling dynamics toward epistemically governed computation and action.

### From understanding a system to governing an act

The path was not a single planned monument.

It grew from successive problems:

How to describe change.  
Then how to model dynamics.  
Then how to separate signal from uncertainty.  
Then how to mark the limits of a model.  
Then how a system should behave when its knowledge is not a sufficient basis for action.

That sequence is the public spine of JANUS:

**observation → experience over time → trajectories → dynamics → state estimation → uncertainty → evidence → knowledge → decision → execution**

Each stage exposed the next problem.

### JANUS

JANUS is a developing research-and-engineering architecture around a broader question:

How can a computational system move from observation to understanding, and then — only where it is justified — from understanding to action, without confusing those stages with one another?

The foundation remains a representation of dynamics.  
The next layer is epistemic evaluation.  
The wider problem is governance.

The central distinction is simple:

**A system may be able to generate an action without being entitled to execute it.**

JANUS therefore treats capability, belief, authority, authorization, and execution as separate notions, rather than assuming that one implies the next.

The aim is not a system that always acts.

The aim is to study whether a system can get better at recognising:

when it should act,  
when it should wait,  
when it should simulate a possible act,  
and when it should admit that its present knowledge is not enough.

### Wider directions

This view is not limited to one kind of data.

Potential research directions include:

- human and behavioural systems — individual trajectories rather than only static aggregates;
- biology and physiology — processes whose meaning appears through evolution in time;
- industry — changing process dynamics and departures from expected behaviour;
- networks and infrastructure — propagation of disturbance, overload, and cascade;
- finance — changing dependence, volatility, and dynamical regimes;
- cyber-physical systems — reasoning under partial observability;
- autonomous and agent systems — separating perception, inference, uncertainty, authorization, and execution;
- scientific computation — keeping observation, model output, hypothesis, and evaluated evidence distinct.

These are **research directions**, not a declaration of universal capability.

The shared rule stays the same:

a system should not be granted more epistemic authority than the available evidence can support.

### What JANUS is actually about

JANUS is not a single algorithm.  
It is not an attempt to explain everything with one model.

It is a developing programme around a difficult question:

How can we represent and reason about a system that changes in time, when we can observe only part of it, our models are imperfect, and the interpretation of observation is itself uncertain?

A mathematical layer concerns dynamics.  
An epistemic layer asks what may reasonably be held on the basis of those dynamics.  
A governance layer concerns the consequences of those holdings.  
An execution layer concerns what, if anything, should happen next.

The interesting place remains the boundary between them.

A system does not become truer only because it becomes more complex.  
It does not become entitled only because it becomes more capable.  
It does not become trustworthy only because its internal model is mathematically elegant.

Trustworthiness begins when a system can tell apart  
what it observed,  
what it inferred,  
what it is only guessing,  
and what it actually has grounds to bring about.

### From one shift of view

The work started by looking at something familiar in a slightly different way.

Not as a pile of static measurements.  
Not as isolated observations.  
As a process passing through successive states.

In time that view became mathematical.  
Mathematics made uncertainty visible.  
Uncertainty made knowledge a problem.  
Knowledge made decision a problem.  
Decision raised one more question:

**What should a system do when it does not know enough?**

JANUS is a continuing attempt to keep that question formal, testable, and honest.

From observation to dynamics.  
From dynamics to epistemology.  
From epistemology to governance.  
And — only where there are grounds for it —  
from knowledge to action.
EOF