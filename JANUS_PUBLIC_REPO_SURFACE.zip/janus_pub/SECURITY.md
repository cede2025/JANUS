# Security Policy

## Reporting

If you discover a security-sensitive issue in materials published in this repository, please report it privately to the maintainers.

Do not open a public issue for reports that may involve:

- exposure of credentials or secrets;
- vulnerabilities in any linked infrastructure;
- information that could aid reconstruction of withheld implementation details.

## Scope of this public repository

This repository is an **evaluation artifact and public architecture surface**. It does not include the full production runtime.

Security-related statements that appear in the evaluation artifact (for example fail-closed audit behavior on the local reference path) are scoped to that documented local/single-node reference. They are not a general security certification.

## Secrets and credentials

- No real user secrets should be present in this repository.
- Placeholder values (e.g. `change-me`) that may appear in reference documentation are development placeholders only.
- Contributors must not commit `.env` files, private keys, tokens, or credentials.

## Responsible disclosure

Please allow reasonable time for assessment before any public discussion of a reported issue.
