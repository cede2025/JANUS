# Validation Report

**Protocol:** JANUS_PUBLIC_CORPUS_VALIDATION_V1  
**Executed:** 2026-09-11  
**Object:** public validation *corpus* integrity (files, hashes, parse, packaging)  
**Not the object:** JANUS mechanism, runtime, estimators, or authorization protocol  
**Not the object:** full public-repository validation

```
44/44 files validated
44/44 SHA256 matched
CSV validation: PASS
JSONL validation: PASS
Packaging consistency: PASS
Claim-status integrity: PASS
JANUS mechanism validation: NOT PERFORMED
```

VALIDATED under this protocol means only:

> public corpus validation under JANUS_PUBLIC_CORPUS_VALIDATION_V1

It does **not** mean:

> VALIDATED: JANUS mechanism

No scientific status of JANUS was raised on the basis of these 44 files.

---

## Change in this run

Six files were renamed `.json` → `.jsonl`.  
Bytes were not changed. Documented SHA256 values were not changed.  
Only the filename in the manifest was updated to match the format.

Domains 11 and 12: extension only. Content unchanged.  
Public-publication status of those domains: unchanged (not cleared).  
EMA license / redistribution: AMBER_REVIEW_REQUIRED (unchanged).

---

## Scope

Checked:

- 44 data files present
- SHA256 of each file against `SOURCES_AND_SHA256.md`
- CSV parse, headers, exact-row duplicate rate
- JSONL parse
- filename extension consistent with format
- no two files byte-identical
- public claim register contains no positive AGI / patent / guarantee language

Not checked:

- JANUS execution mechanism
- dynamics estimators
- authorization protocol
- V1.2 empirical boundary
- scientific adequacy of any domain sample
- redistribution licenses

---

## Machine log

`corpus_validation_results.json`  
137 PASS, 0 FAIL  

JANUS mechanism validation: NOT PERFORMED

---

## Reading rule

A corpus PASS is a statement about archived bytes and documentation.  
It is not a statement about JANUS.
